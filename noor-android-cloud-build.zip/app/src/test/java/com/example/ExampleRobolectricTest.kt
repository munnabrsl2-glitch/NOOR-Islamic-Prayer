package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.AppLanguage
import com.example.data.model.CalculationMethod
import com.example.data.model.JuristicMethod
import com.example.data.prayer.AstronomicalPrayerCalculator
import com.example.data.prayer.HijriCalendar
import com.example.util.BengaliNumberUtil
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.Calendar
import java.util.TimeZone

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("NOOR", appName)
    }

    @Test
    fun `astronomical prayer calculations are valid and ordered`() {
        val cal = Calendar.getInstance(TimeZone.getTimeZone("Asia/Dhaka")).apply {
            set(2026, Calendar.NOVEMBER, 12, 12, 0, 0)
        }

        val schedule = AstronomicalPrayerCalculator.calculateSchedule(
            calendar = cal,
            latitude = 23.8103,
            longitude = 90.4125,
            method = CalculationMethod.BANGLADESH,
            juristicMethod = JuristicMethod.HANAFI
        )

        assertTrue("Fajr must be before Sunrise", schedule.fajr < schedule.sunrise)
        assertTrue("Sunrise must be before Dhuhr", schedule.sunrise < schedule.dhuhr)
        assertTrue("Dhuhr must be before Asr", schedule.dhuhr < schedule.asr)
        assertTrue("Asr must be before Maghrib", schedule.asr < schedule.maghrib)
        assertTrue("Maghrib must be before Isha", schedule.maghrib < schedule.isha)
    }

    @Test
    fun `hanafi asr is later than shafi asr`() {
        val cal = Calendar.getInstance(TimeZone.getTimeZone("Asia/Dhaka")).apply {
            set(2026, Calendar.NOVEMBER, 12, 12, 0, 0)
        }

        val hanafiSchedule = AstronomicalPrayerCalculator.calculateSchedule(
            calendar = cal,
            latitude = 23.8103,
            longitude = 90.4125,
            method = CalculationMethod.BANGLADESH,
            juristicMethod = JuristicMethod.HANAFI
        )

        val shafiSchedule = AstronomicalPrayerCalculator.calculateSchedule(
            calendar = cal,
            latitude = 23.8103,
            longitude = 90.4125,
            method = CalculationMethod.BANGLADESH,
            juristicMethod = JuristicMethod.SHAFI
        )

        assertTrue(
            "Hanafi Asr must be later than Shafi Asr",
            hanafiSchedule.asr > shafiSchedule.asr
        )
    }

    @Test
    fun `bengali number formatting converts digits accurately`() {
        val formatted = BengaliNumberUtil.formatNumber("12:34 PM", AppLanguage.BENGALI)
        assertEquals("১২:৩৪ PM", formatted)

        val number = BengaliNumberUtil.formatNumber(1448, AppLanguage.BENGALI)
        assertEquals("১৪৪৮", number)
    }

    @Test
    fun `hijri calendar calculates valid year and month`() {
        val cal = Calendar.getInstance().apply {
            set(2026, Calendar.NOVEMBER, 12)
        }
        val hijri = HijriCalendar.getHijriDate(cal)
        assertTrue("Hijri year should be around 1448 AH", hijri.year in 1447..1449)
        assertTrue("Hijri month should be 1-12", hijri.month in 1..12)
        assertTrue("Hijri day should be 1-30", hijri.day in 1..30)
    }
}
