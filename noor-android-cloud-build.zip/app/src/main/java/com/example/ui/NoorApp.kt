package com.example.ui

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CompassCalibration
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.AppLanguage
import com.example.ui.home.HomeScreen
import com.example.ui.more.MoreScreen
import com.example.ui.qibla.QiblaScreen
import com.example.ui.quran.QuranScreen
import com.example.ui.splash.SplashScreen
import com.example.ui.tasbih.TasbihScreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary

enum class NavTab(
    val route: String,
    val titleBn: String,
    val titleEn: String,
    val activeIcon: ImageVector,
    val inactiveIcon: ImageVector
) {
    HOME("home", "হোম", "Home", Icons.Filled.Home, Icons.Outlined.Home),
    QURAN("quran", "কুরআন", "Quran", Icons.Filled.MenuBook, Icons.Outlined.MenuBook),
    QIBLA("qibla", "কিবলা", "Qibla", Icons.Filled.Explore, Icons.Outlined.Explore),
    TASBIH("tasbih", "তাসবীহ", "Tasbih", Icons.Filled.AutoAwesome, Icons.Filled.AutoAwesome),
    MORE("more", "অন্যান্য", "More", Icons.Filled.MoreHoriz, Icons.Outlined.MoreHoriz)
}

@Composable
fun NoorApp(
    viewModel: MainViewModel = viewModel()
) {
    var showSplash by remember { mutableStateOf(true) }
    var currentTab by remember { mutableStateOf(NavTab.HOME) }

    val prefs by viewModel.preferences.collectAsState()
    val lang = prefs?.language ?: AppLanguage.BENGALI

    if (showSplash) {
        SplashScreen(onSplashFinished = { showSplash = false })
    } else {
        Scaffold(
            bottomBar = {
                Surface(
                    color = DarkSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldBorder.copy(alpha = 0.4f)),
                    modifier = Modifier.testTag("bottom_nav_bar")
                ) {
                    NavigationBar(
                        containerColor = DarkSurface,
                        contentColor = GoldLight,
                        tonalElevation = 8.dp
                    ) {
                        NavTab.entries.forEach { tab ->
                            val isSelected = currentTab == tab
                            NavigationBarItem(
                                selected = isSelected,
                                onClick = { currentTab = tab },
                                icon = {
                                    Icon(
                                        imageVector = if (isSelected) tab.activeIcon else tab.inactiveIcon,
                                        contentDescription = tab.titleEn,
                                        modifier = Modifier.testTag("nav_item_${tab.route}")
                                    )
                                },
                                label = {
                                    Text(
                                        text = if (lang == AppLanguage.BENGALI) tab.titleBn else tab.titleEn,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.Black,
                                    selectedTextColor = GoldLight,
                                    unselectedIconColor = TextMuted,
                                    unselectedTextColor = TextMuted,
                                    indicatorColor = GoldPrimary
                                )
                            )
                        }
                    }
                }
            },
            containerColor = DarkBackground
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                Crossfade(targetState = currentTab, label = "tab_fade") { tab ->
                    when (tab) {
                        NavTab.HOME -> HomeScreen(viewModel = viewModel)
                        NavTab.QURAN -> QuranScreen(viewModel = viewModel)
                        NavTab.QIBLA -> QiblaScreen(viewModel = viewModel)
                        NavTab.TASBIH -> TasbihScreen(viewModel = viewModel)
                        NavTab.MORE -> MoreScreen(viewModel = viewModel)
                    }
                }
            }
        }
    }
}
