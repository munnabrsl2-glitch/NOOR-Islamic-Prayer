package com.example.ui.settings

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AdhanAudioOption
import com.example.data.model.AppLanguage
import com.example.data.model.CalculationMethod
import com.example.data.model.JuristicMethod
import com.example.ui.MainViewModel
import com.example.ui.components.IslamicGeometricDivider
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.BengaliNumberUtil

@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val prefs by viewModel.preferences.collectAsState()
    val isTestingAdhan by viewModel.isTestingAdhan.collectAsState()
    val lang = prefs?.language ?: AppLanguage.BENGALI

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .testTag("settings_screen"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp)
    ) {
        // Screen Title
        item {
            Column(modifier = Modifier.padding(bottom = 16.dp)) {
                Text(
                    text = if (lang == AppLanguage.BENGALI) "সেটিংস ও কাস্টমাইজেশন" else "Settings & Customization",
                    color = GoldLight,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (lang == AppLanguage.BENGALI) "আজান, ভাষা, হিসাব পদ্ধতি ও নোটিফিকেশন নিয়ন্ত্রণ" else "Adhan, Language, Calculation Methods & Controls",
                    color = TextMuted,
                    fontSize = 12.sp
                )
            }
        }

        // Section 1: Language
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldBorder.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Language, contentDescription = "Language", tint = GoldPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (lang == AppLanguage.BENGALI) "অ্যাপের ভাষা (Language)" else "App Language",
                            color = GoldLight,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        AppLanguage.entries.forEach { l ->
                            FilterChip(
                                selected = l == lang,
                                onClick = { viewModel.setLanguage(l) },
                                label = { Text(l.nativeName, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = GoldPrimary,
                                    selectedLabelColor = Color.Black
                                )
                            )
                        }
                    }
                }
            }
        }

        // Section 2: Complete Adhan System
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldBorder.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Notifications, contentDescription = "Adhan", tint = GoldPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (lang == AppLanguage.BENGALI) "আজান অডিও ও অ্যালার্ম" else "Adhan Audio & Alarm",
                                color = GoldLight,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Test Adhan Button
                        Button(
                            onClick = {
                                prefs?.let { viewModel.toggleTestAdhan(it.adhanAudio) }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isTestingAdhan) Color(0xFFCF6679) else GoldPrimary
                            ),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.testTag("test_adhan_button")
                        ) {
                            Icon(
                                imageVector = if (isTestingAdhan) Icons.Default.Stop else Icons.Default.PlayArrow,
                                contentDescription = "Test Adhan",
                                tint = Color.Black,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isTestingAdhan) "বন্ধ করুন" else "টেস্ট আজান",
                                color = Color.Black,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = if (lang == AppLanguage.BENGALI) "আজান কণ্ঠস্বর নির্বাচন:" else "Select Adhan Reciter:",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    AdhanAudioOption.entries.forEach { opt ->
                        val isSel = opt == (prefs?.adhanAudio ?: AdhanAudioOption.MAKKAH)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSel) GoldContainer else Color.Transparent)
                                .clickable { viewModel.setAdhanAudio(opt) }
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = opt.title,
                                color = if (isSel) GoldLight else TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                            )
                            if (isSel) {
                                Text(text = "✓", color = GoldPrimary, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    IslamicGeometricDivider()
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = if (lang == AppLanguage.BENGALI) "প্রতিটি ওয়াক্তের আজান সক্রিয় রাখুন:" else "Prayer Alarms Enabled:",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    val prayerSwitches = listOf(
                        Triple("fajr", "ফজর (Fajr)", prefs?.fajrEnabled ?: true),
                        Triple("dhuhr", "যোহর (Dhuhr)", prefs?.dhuhrEnabled ?: true),
                        Triple("asr", "আসর (Asr)", prefs?.asrEnabled ?: true),
                        Triple("maghrib", "মাগরিব (Maghrib)", prefs?.maghribEnabled ?: true),
                        Triple("isha", "এশা (Isha)", prefs?.ishaEnabled ?: true)
                    )

                    prayerSwitches.forEach { (id, title, isEnabled) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = title, color = TextPrimary, fontSize = 14.sp)
                            Switch(
                                checked = isEnabled,
                                onCheckedChange = { viewModel.togglePrayerAdhanEnabled(id, it) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.Black,
                                    checkedTrackColor = GoldPrimary
                                )
                            )
                        }
                    }
                }
            }
        }

        // Section 3: Calculation Method & Madhhab
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldBorder.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Schedule, contentDescription = "Calculation", tint = GoldPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (lang == AppLanguage.BENGALI) "নামাজের সময় হিসাব পদ্ধতি" else "Calculation Method",
                            color = GoldLight,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    CalculationMethod.entries.forEach { method ->
                        val isSel = method == (prefs?.calculationMethod ?: CalculationMethod.BANGLADESH)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSel) GoldContainer else Color.Transparent)
                                .clickable { viewModel.setCalculationMethod(method) }
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = method.getTitle(lang),
                                    color = if (isSel) GoldLight else TextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                                )
                                Text(
                                    text = "ফজর: ${method.fajrAngle}°, এশা: ${if (method.ishaMinutesAfterMaghrib != null) "মাগরিবের ৯০ মি. পর" else "${method.ishaAngle}°"}",
                                    color = TextMuted,
                                    fontSize = 11.sp
                                )
                            }
                            if (isSel) {
                                Text(text = "✓", color = GoldPrimary, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    IslamicGeometricDivider()
                    Spacer(modifier = Modifier.height(12.dp))

                    // Asr Madhhab
                    Text(
                        text = if (lang == AppLanguage.BENGALI) "আসর নামাজের মাযহাব:" else "Asr Juristic Method:",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    JuristicMethod.entries.forEach { jMethod ->
                        val isSel = jMethod == (prefs?.juristicMethod ?: JuristicMethod.HANAFI)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSel) GoldContainer else Color.Transparent)
                                .clickable { viewModel.setJuristicMethod(jMethod) }
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = jMethod.getTitle(lang),
                                color = if (isSel) GoldLight else TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                            )
                            if (isSel) {
                                Text(text = "✓", color = GoldPrimary, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Section 4: Battery Optimization & Exact Alarms Guide
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldBorder.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.BatteryAlert, contentDescription = "Battery", tint = GoldLight)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (lang == AppLanguage.BENGALI) "ব্যাটারি অপ্টিমাইজেশন ও অ্যালার্ম সুরক্ষা" else "Battery Optimization & Alarms",
                            color = GoldLight,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (lang == AppLanguage.BENGALI) {
                            "সময়মতো নিখুঁত আজান বাজানোর জন্য অ্যান্ড্রয়েড সিস্টেমে অ্যাপটির 'Battery Optimization' বন্ধ (Unrestricted) রাখা প্রয়োজন। কিছু ডিভাইসে (Xiaomi, Vivo, Oppo, Samsung) ব্যাকগ্রাউন্ড প্রসেস বন্ধ করে দেওয়া হয়, যার ফলে অ্যাপের জন্য অটো-স্টার্ট অনুমতি চালু রাখতে হয়।"
                        } else {
                            "To ensure Adhan alarms play reliably when the screen is locked, disable battery optimization for NOOR in Android settings."
                        },
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedButton(
                        onClick = {
                            try {
                                val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                val intent = Intent(Settings.ACTION_SETTINGS)
                                context.startActivity(intent)
                            }
                        },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = GoldLight),
                        border = androidx.compose.foundation.BorderStroke(1.dp, GoldBorder)
                    ) {
                        Text(
                            text = if (lang == AppLanguage.BENGALI) "ব্যাটারি সেটিংস খুলুন" else "Open Battery Settings",
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Section 5: Firebase Cloud Setup Instructions
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldBorder.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Cloud, contentDescription = "Cloud", tint = GoldPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (lang == AppLanguage.BENGALI) "ক্লাউড ব্যাকআপ ও ফায়ারবেস নির্দেশিকা" else "Cloud Sync & Firebase Guide",
                            color = GoldLight,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (lang == AppLanguage.BENGALI) {
                            "বর্তমানে অ্যাপটি সম্পূর্ণ অফলাইনে নিরাপদ Room ডাটাবেসে আপনার নামাজ ও বুকমার্ক সংরক্ষণ করে। ভবিষ্যতে একাধিক ডিভাইসে স্বয়ংক্রিয় ক্লাউড সিঙ্ক চালু করতে:\n\n১. Firebase Console-এ নতুন প্রজেক্ট তৈরি করুন।\n২. 'google-services.json' ফাইলটি app ফোল্ডারে যোগ করুন।\n৩. Google Sign-In এবং Cloud Firestore রুলস সক্রিয় করুন।\n\nঅ্যাপটি অফলাইনে আজীবন নিরবচ্ছিন্নভাবে কাজ করবে।"
                        } else {
                            "NOOR stores all your data securely on-device with Room database. To enable multi-device sync with Firebase in the future, add your google-services.json, enable Firestore & Google Sign-In in Firebase Console."
                        },
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        // Section 6: About the App
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldBorder.copy(alpha = 0.3f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "নূর • NOOR – Islamic Prayer",
                        color = GoldLight,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Version 1.0.0 (Release)",
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "সঠিক নামাজের ওয়াক্ত, আজান অ্যালার্ম, ডিজিটাল তাসবীহ, আল-কুরআন ও বিশুদ্ধ দৈনন্দিন দুআ সম্বলিত একটি মার্জিত ইসলামিক অ্যাপ্লিকেশন।",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        lineHeight = 16.sp
                    )
                }
            }
            Spacer(modifier = Modifier.height(96.dp))
        }
    }
}
