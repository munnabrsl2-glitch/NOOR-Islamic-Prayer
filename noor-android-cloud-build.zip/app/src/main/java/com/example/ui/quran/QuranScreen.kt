package com.example.ui.quran

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.ui.MainViewModel
import com.example.ui.components.IslamicBismillahBanner
import com.example.ui.components.IslamicGeometricDivider
import com.example.ui.components.IslamicStarBadge
import com.example.ui.theme.ArabicFontFamily
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.BengaliNumberUtil
import com.example.util.QuranData
import com.example.util.SurahInfo

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuranScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val prefs by viewModel.preferences.collectAsState()
    val bookmarks by viewModel.bookmarks.collectAsState()
    val lang = prefs?.language ?: AppLanguage.BENGALI

    var selectedSurah by remember { mutableStateOf<SurahInfo?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    var filterType by remember { mutableStateOf("ALL") } // ALL, MAKKI, MADANI, BOOKMARKS

    var arabicFontSize by remember { mutableFloatStateOf(24f) }

    // Intercept back button when inside a Surah reading view
    BackHandler(enabled = selectedSurah != null) {
        selectedSurah = null
    }

    if (selectedSurah != null) {
        // Ayah Reading View
        val surah = selectedSurah!!
        val ayahs = remember(surah.number) { QuranData.getAyahsForSurah(surah.number) }

        Column(
            modifier = modifier
                .fillMaxSize()
                .background(DarkBackground)
                .testTag("quran_ayah_view")
        ) {
            // Header
            Surface(
                color = DarkSurface,
                modifier = Modifier.fillMaxWidth(),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldBorder.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { selectedSurah = null },
                        modifier = Modifier.testTag("back_to_surah_list_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = GoldPrimary
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${surah.nameBn} (${surah.nameEn})",
                            color = GoldLight,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${surah.bengaliMeaning} • ${if (surah.isMakki) "মাক্কী" else "মাদানী"} • ${BengaliNumberUtil.formatNumber(surah.versesCount, lang)} আয়াত",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }

                    Text(
                        text = surah.nameAr,
                        fontFamily = ArabicFontFamily,
                        color = GoldPrimary,
                        fontSize = 24.sp,
                        modifier = Modifier.padding(end = 12.dp)
                    )
                }
            }

            // Font size slider bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurfaceVariant)
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "A-", color = TextMuted, fontSize = 12.sp)
                Slider(
                    value = arabicFontSize,
                    onValueChange = { arabicFontSize = it },
                    valueRange = 18f..36f,
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 12.dp),
                    colors = SliderDefaults.colors(
                        thumbColor = GoldPrimary,
                        activeTrackColor = GoldPrimary,
                        inactiveTrackColor = GoldBorder
                    )
                )
                Text(text = "A+", color = GoldLight, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp)
            ) {
                if (surah.number != 9) {
                    item {
                        IslamicBismillahBanner(modifier = Modifier.padding(bottom = 16.dp))
                    }
                }

                items(ayahs) { ayah ->
                    val refId = "ayah_${ayah.surahNumber}_${ayah.ayahNumber}"
                    val isBookmarked = bookmarks.any { it.referenceId == refId }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, GoldBorder.copy(alpha = 0.4f))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            // Ayah Top Bar: Number & Bookmark
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IslamicStarBadge(
                                    number = BengaliNumberUtil.formatNumber(ayah.ayahNumber, lang),
                                    isHighlighted = false
                                )

                                IconButton(
                                    onClick = {
                                        viewModel.toggleBookmark(
                                            type = "quran_ayah",
                                            refId = refId,
                                            title = "${surah.nameBn} - আয়াত ${ayah.ayahNumber}",
                                            subtitle = ayah.pronunciationBn,
                                            arabic = ayah.arabicText,
                                            trans = ayah.translationBn
                                        )
                                    },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isBookmarked) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                                        contentDescription = "Bookmark Ayah",
                                        tint = if (isBookmarked) GoldPrimary else TextMuted
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Arabic Quran text
                            Text(
                                text = "${ayah.arabicText} ﴿${ayah.ayahNumber}﴾",
                                fontFamily = ArabicFontFamily,
                                fontSize = arabicFontSize.sp,
                                lineHeight = (arabicFontSize * 1.6f).sp,
                                color = GoldLight,
                                textAlign = TextAlign.End,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(12.dp))
                            IslamicGeometricDivider()
                            Spacer(modifier = Modifier.height(10.dp))

                            // Pronunciation (Transliteration)
                            Text(
                                text = "উচ্চারণ: ${ayah.pronunciationBn}",
                                color = TextSecondary,
                                fontSize = 13.sp,
                                lineHeight = 20.sp,
                                fontWeight = FontWeight.Medium
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            // Bengali Translation
                            Text(
                                text = "অর্থ: ${ayah.translationBn}",
                                color = TextPrimary,
                                fontSize = 14.sp,
                                lineHeight = 22.sp
                            )
                        }
                    }
                }
            }
        }
    } else {
        // Surah List View
        val allSurahs = QuranData.SURAH_LIST
        val filtered = remember(searchQuery, filterType) {
            allSurahs.filter { surah ->
                val matchesQuery = searchQuery.isBlank() ||
                        surah.nameBn.contains(searchQuery, ignoreCase = true) ||
                        surah.nameEn.contains(searchQuery, ignoreCase = true) ||
                        surah.number.toString().contains(searchQuery)

                val matchesFilter = when (filterType) {
                    "MAKKI" -> surah.isMakki
                    "MADANI" -> !surah.isMakki
                    else -> true
                }

                matchesQuery && matchesFilter
            }
        }

        Column(
            modifier = modifier
                .fillMaxSize()
                .background(DarkBackground)
                .testTag("quran_screen")
        ) {
            // Header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurface)
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (lang == AppLanguage.BENGALI) "আল-কুরআনুল কারীম" else "Al-Quran Al-Kareem",
                            color = GoldLight,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (lang == AppLanguage.BENGALI) "১১৪টি সম্পূর্ণ সূরার তালিকা ও আয়াত" else "114 Surahs Directory",
                            color = TextMuted,
                            fontSize = 12.sp
                        )
                    }

                    Text(
                        text = "القرآن الكريم",
                        fontFamily = ArabicFontFamily,
                        color = GoldPrimary,
                        fontSize = 24.sp
                    )
                }
            }

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("সূরা খুঁজুন (e.g. ফাতিহা, ইয়াসীন, বাকারা...)", fontSize = 13.sp) },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = "Search", tint = GoldLight)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("quran_search_input"),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GoldPrimary,
                    unfocusedBorderColor = GoldBorder
                )
            )

            // Filter Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = filterType == "ALL",
                    onClick = { filterType = "ALL" },
                    label = { Text("সকল সূরা (${allSurahs.size})", fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = GoldPrimary,
                        selectedLabelColor = Color.Black
                    )
                )

                FilterChip(
                    selected = filterType == "MAKKI",
                    onClick = { filterType = "MAKKI" },
                    label = { Text("মাক্কী সূরা", fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = GoldPrimary,
                        selectedLabelColor = Color.Black
                    )
                )

                FilterChip(
                    selected = filterType == "MADANI",
                    onClick = { filterType = "MADANI" },
                    label = { Text("মাদানী সূরা", fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = GoldPrimary,
                        selectedLabelColor = Color.Black
                    )
                )
            }

            // Surahs List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 8.dp, bottom = 96.dp)
            ) {
                items(filtered) { surah ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { selectedSurah = surah }
                            .testTag("surah_card_${surah.number}"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, GoldBorder.copy(alpha = 0.35f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IslamicStarBadge(
                                    number = BengaliNumberUtil.formatNumber(surah.number, lang)
                                )

                                Spacer(modifier = Modifier.width(14.dp))

                                Column {
                                    Text(
                                        text = surah.nameBn,
                                        color = TextPrimary,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${surah.nameEn} • ${surah.bengaliMeaning}",
                                        color = TextSecondary,
                                        fontSize = 12.sp
                                    )
                                    Text(
                                        text = "${if (surah.isMakki) "মাক্কী" else "মাদানী"} • ${BengaliNumberUtil.formatNumber(surah.versesCount, lang)} আয়াত",
                                        color = TextMuted,
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            Text(
                                text = surah.nameAr,
                                fontFamily = ArabicFontFamily,
                                color = GoldPrimary,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Normal
                            )
                        }
                    }
                }
            }
        }
    }
}
