package com.example.ui.more

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.ui.MainViewModel
import com.example.ui.calendar.IslamicCalendarScreen
import com.example.ui.dua.DuaScreen
import com.example.ui.settings.SettingsScreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.tracker.PrayerTrackerScreen

enum class MoreSubScreen {
    MENU,
    TRACKER,
    DUA,
    CALENDAR,
    SETTINGS
}

data class MoreMenuItem(
    val id: MoreSubScreen,
    val titleBn: String,
    val titleEn: String,
    val subtitleBn: String,
    val subtitleEn: String,
    val icon: ImageVector
)

@Composable
fun MoreScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val prefs by viewModel.preferences.collectAsState()
    val lang = prefs?.language ?: AppLanguage.BENGALI

    var currentSubScreen by remember { mutableStateOf(MoreSubScreen.MENU) }

    // Intercept back button when inside a subscreen
    BackHandler(enabled = currentSubScreen != MoreSubScreen.MENU) {
        currentSubScreen = MoreSubScreen.MENU
    }

    when (currentSubScreen) {
        MoreSubScreen.TRACKER -> {
            Column(modifier = modifier.fillMaxSize()) {
                SubScreenHeader(
                    title = if (lang == AppLanguage.BENGALI) "নামাজ ট্র্যাকার" else "Prayer Tracker",
                    onBack = { currentSubScreen = MoreSubScreen.MENU }
                )
                PrayerTrackerScreen(viewModel = viewModel)
            }
        }
        MoreSubScreen.DUA -> {
            Column(modifier = modifier.fillMaxSize()) {
                SubScreenHeader(
                    title = if (lang == AppLanguage.BENGALI) "দৈনন্দিন দুআ" else "Daily Dua",
                    onBack = { currentSubScreen = MoreSubScreen.MENU }
                )
                DuaScreen(viewModel = viewModel)
            }
        }
        MoreSubScreen.CALENDAR -> {
            Column(modifier = modifier.fillMaxSize()) {
                SubScreenHeader(
                    title = if (lang == AppLanguage.BENGALI) "হিজরি ক্যালেন্ডার ও রমজান" else "Islamic Calendar & Ramadan",
                    onBack = { currentSubScreen = MoreSubScreen.MENU }
                )
                IslamicCalendarScreen(viewModel = viewModel)
            }
        }
        MoreSubScreen.SETTINGS -> {
            Column(modifier = modifier.fillMaxSize()) {
                SubScreenHeader(
                    title = if (lang == AppLanguage.BENGALI) "সেটিংস ও আজান" else "Settings & Adhan",
                    onBack = { currentSubScreen = MoreSubScreen.MENU }
                )
                SettingsScreen(viewModel = viewModel)
            }
        }
        MoreSubScreen.MENU -> {
            val menuItems = listOf(
                MoreMenuItem(
                    id = MoreSubScreen.TRACKER,
                    titleBn = "নামাজ ট্র্যাকার ও অগ্রগতি",
                    titleEn = "Prayer Tracker & History",
                    subtitleBn = "দৈনন্দিন ৫ ওয়াক্ত নামাজের হিসাব ও রুটিন",
                    subtitleEn = "Log your 5 daily prayers and streaks",
                    icon = Icons.Default.CheckCircle
                ),
                MoreMenuItem(
                    id = MoreSubScreen.DUA,
                    titleBn = "হিসনুল মুসলিম ও দুআ ভাণ্ডার",
                    titleEn = "Daily Duas & Azkar",
                    subtitleBn = "সকাল-সন্ধ্যা, খাবার, ঘুম ও বিপদ মুক্তির দুআ",
                    subtitleEn = "Authentic supplications from Hisnul Muslim",
                    icon = Icons.Default.MenuBook
                ),
                MoreMenuItem(
                    id = MoreSubScreen.CALENDAR,
                    titleBn = "হিজরি ক্যালেন্ডার ও মাহে রমজান",
                    titleEn = "Hijri Calendar & Ramadan",
                    subtitleBn = "রমজান মাসের সেহরি-ইফতারের পূর্ণ সময়সূচি ও দিবস",
                    subtitleEn = "Full 30-day Ramadan timetable & events",
                    icon = Icons.Default.CalendarMonth
                ),
                MoreMenuItem(
                    id = MoreSubScreen.SETTINGS,
                    titleBn = "সেটিংস ও আজান কনফিগারেশন",
                    titleEn = "Settings & Adhan",
                    subtitleBn = "আজান টেস্ট, অডিও নির্বাচন, মাযহাব ও ভাষা",
                    subtitleEn = "Adhan audio, Madhhab, Method & Language",
                    icon = Icons.Default.Settings
                )
            )

            LazyColumn(
                modifier = modifier
                    .fillMaxSize()
                    .background(DarkBackground)
                    .testTag("more_screen_menu"),
                contentPadding = PaddingValues(bottom = 96.dp)
            ) {
                // Header
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(DarkSurface)
                            .padding(horizontal = 20.dp, vertical = 16.dp)
                    ) {
                        Column {
                            Text(
                                text = if (lang == AppLanguage.BENGALI) "ইসলামিক অন্যান্য ফিচার" else "More Islamic Features",
                                color = GoldLight,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (lang == AppLanguage.BENGALI) "ট্র্যাকার, দুআ, ক্যালেন্ডার ও সেটিংস" else "Tracker, Dua, Calendar & Settings",
                                color = TextMuted,
                                fontSize = 12.sp
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }

                items(menuItems) { item ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .clickable { currentSubScreen = item.id }
                            .testTag("more_menu_${item.id.name.lowercase()}"),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, GoldBorder.copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = GoldContainer,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldBorder),
                                    modifier = Modifier.size(44.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = item.icon,
                                            contentDescription = item.titleBn,
                                            tint = GoldPrimary,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(14.dp))

                                Column {
                                    Text(
                                        text = if (lang == AppLanguage.BENGALI) item.titleBn else item.titleEn,
                                        color = TextPrimary,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = if (lang == AppLanguage.BENGALI) item.subtitleBn else item.subtitleEn,
                                        color = TextSecondary,
                                        fontSize = 12.sp
                                    )
                                }
                            }

                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = "Open",
                                tint = GoldLight,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SubScreenHeader(
    title: String,
    onBack: () -> Unit
) {
    Surface(
        color = DarkSurface,
        modifier = Modifier.fillMaxWidth(),
        border = androidx.compose.foundation.BorderStroke(1.dp, GoldBorder.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = GoldPrimary
                )
            }
            Text(
                text = title,
                color = GoldLight,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
