package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ArabicFontFamily
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary

@Composable
fun IslamicBismillahBanner(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(DarkSurfaceVariant)
            .border(1.dp, GoldBorder, RoundedCornerShape(12.dp))
            .padding(vertical = 12.dp, horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
            fontFamily = ArabicFontFamily,
            fontSize = 22.sp,
            fontWeight = FontWeight.Normal,
            color = GoldPrimary
        )
    }
}

@Composable
fun IslamicGeometricDivider(modifier: Modifier = Modifier) {
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(16.dp)
            .padding(horizontal = 24.dp)
    ) {
        val midY = size.height / 2
        val midX = size.width / 2

        // Line left
        drawLine(
            brush = Brush.horizontalGradient(
                listOf(Color.Transparent, GoldPrimary.copy(alpha = 0.6f))
            ),
            start = Offset(0f, midY),
            end = Offset(midX - 16.dp.toPx(), midY),
            strokeWidth = 1.dp.toPx()
        )

        // Center diamond
        val diamondPath = Path().apply {
            moveTo(midX, midY - 6.dp.toPx())
            lineTo(midX + 6.dp.toPx(), midY)
            lineTo(midX, midY + 6.dp.toPx())
            lineTo(midX - 6.dp.toPx(), midY)
            close()
        }
        drawPath(diamondPath, color = GoldPrimary)

        // Line right
        drawLine(
            brush = Brush.horizontalGradient(
                listOf(GoldPrimary.copy(alpha = 0.6f), Color.Transparent)
            ),
            start = Offset(midX + 16.dp.toPx(), midY),
            end = Offset(size.width, midY),
            strokeWidth = 1.dp.toPx()
        )
    }
}

@Composable
fun IslamicStarBadge(
    number: String,
    modifier: Modifier = Modifier,
    isHighlighted: Boolean = false
) {
    Box(
        modifier = modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(if (isHighlighted) GoldPrimary else DarkSurface)
            .border(
                width = 1.5.dp,
                color = if (isHighlighted) GoldLight else GoldBorder,
                shape = CircleShape
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = number,
            color = if (isHighlighted) Color.Black else GoldPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun PulsingGoldGlow(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "gold_glow")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_alpha"
    )

    Box(
        modifier = modifier
            .border(
                width = 1.5.dp,
                color = GoldPrimary.copy(alpha = alpha),
                shape = RoundedCornerShape(16.dp)
            )
    ) {
        content()
    }
}
