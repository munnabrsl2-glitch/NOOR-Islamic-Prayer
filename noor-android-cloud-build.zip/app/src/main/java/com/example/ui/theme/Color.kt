package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Black & Gold Theme Colors
val DarkBackground = Color(0xFF080808)
val DarkSurface = Color(0xFF131313)
val DarkSurfaceVariant = Color(0xFF1C1B17)
val DarkSurfaceElevated = Color(0xFF24231E)

val GoldPrimary = Color(0xFFD4AF37)
val GoldLight = Color(0xFFF7E7A3)
val GoldDeep = Color(0xFFAA820A)
val GoldContainer = Color(0xFF2B2411)
val GoldOnContainer = Color(0xFFFFECC0)
val GoldBorder = Color(0xFF4A3E1E)
val GoldAccentGlow = Color(0xFFFFDF70)

val TextPrimary = Color(0xFFF7F5EE)
val TextSecondary = Color(0xFFC7C2B2)
val TextMuted = Color(0xFF8A8576)

val EmeraldGreen = Color(0xFF2E7D32)
val EmeraldLight = Color(0xFF81C784)
val SunsetOrange = Color(0xFFE65100)

val ErrorRed = Color(0xFFCF6679)
