package com.example.ui.calendar

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Event
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.prayer.AstronomicalPrayerCalculator
import com.example.data.prayer.HijriCalendar
import com.example.ui.MainViewModel
import com.example.ui.components.IslamicGeometricDivider
import com.example.ui.components.IslamicStarBadge
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.BengaliNumberUtil
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

data class RamadanDayItem(
    val ramadanDay: Int,
    val gregorianDateStr: String,
    val sehriTimeStr: String,
    val iftarTimeStr: String
)

@Composable
fun IslamicCalendarScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val homeState by viewModel.homeState.collectAsState()
    val prefs by viewModel.preferences.collectAsState()
    val lang = prefs?.language ?: AppLanguage.BENGALI

    var selectedTab by remember { mutableStateOf("RAMADAN") } // RAMADAN, EVENTS

    // Calculate 30-day Ramadan timetable based on current location and calculation method
    val ramadanSchedule = remember(homeState.location, prefs?.calculationMethod) {
        val list = mutableListOf<RamadanDayItem>()
        val cal = Calendar.getInstance(TimeZone.getTimeZone(homeState.location.timezoneId))
        val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault()).apply {
            timeZone = TimeZone.getTimeZone(homeState.location.timezoneId)
        }
        val dateFormat = SimpleDateFormat("d MMM, EEE", Locale.getDefault()).apply {
            timeZone = TimeZone.getTimeZone(homeState.location.timezoneId)
        }

        for (i in 1..30) {
            val dayCal = (cal.clone() as Calendar).apply {
                add(Calendar.DAY_OF_YEAR, i - 1)
            }
            val sched = AstronomicalPrayerCalculator.calculateSchedule(
                calendar = dayCal,
                latitude = homeState.location.latitude,
                longitude = homeState.location.longitude,
                method = prefs?.calculationMethod ?: com.example.data.model.CalculationMethod.BANGLADESH,
                juristicMethod = prefs?.juristicMethod ?: com.example.data.model.JuristicMethod.HANAFI
            )

            list.add(
                RamadanDayItem(
                    ramadanDay = i,
                    gregorianDateStr = dateFormat.format(dayCal.time),
                    sehriTimeStr = timeFormat.format(sched.sehriEnd),
                    iftarTimeStr = timeFormat.format(sched.iftarTime)
                )
            )
        }
        list
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .testTag("islamic_calendar_screen"),
        contentPadding = PaddingValues(bottom = 96.dp)
    ) {
        // Header
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurface)
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Column {
                    Text(
                        text = if (lang == AppLanguage.BENGALI) "হিজরি ক্যালেন্ডার ও রমজান" else "Islamic Calendar & Ramadan",
                        color = GoldLight,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${homeState.location.cityName} • সেহরি ও ইফতারের ক্যালেন্ডার",
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // Current Hijri Date Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = GoldContainer),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(text = "🌙", fontSize = 28.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    homeState.hijriDate?.let { hijri ->
                        Text(
                            text = if (lang == AppLanguage.BENGALI) hijri.formattedBn else hijri.formattedEn,
                            color = GoldLight,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = if (lang == AppLanguage.BENGALI) homeState.currentDateGregorianBn else homeState.currentDateGregorianEn,
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                }
            }
        }

        // Tab Selector
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedTab == "RAMADAN",
                    onClick = { selectedTab = "RAMADAN" },
                    label = { Text("মাহে রমজান সময়সূচি", fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = GoldPrimary,
                        selectedLabelColor = Color.Black
                    )
                )

                FilterChip(
                    selected = selectedTab == "EVENTS",
                    onClick = { selectedTab = "EVENTS" },
                    label = { Text("গুরুত্বপূর্ণ ইসলামিক দিবস", fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = GoldPrimary,
                        selectedLabelColor = Color.Black
                    )
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        if (selectedTab == "RAMADAN") {
            // Ramadan Table Header
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(DarkSurfaceElevated)
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "রোজা", color = GoldLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(text = "তারিখ", color = GoldLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(text = "সেহরি শেষ", color = GoldLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(text = "ইফতার", color = GoldLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Ramadan 30 Days List
            items(ramadanSchedule) { item ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 3.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldBorder.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${BengaliNumberUtil.formatNumber(item.ramadanDay, lang)} রমজান",
                            color = GoldLight,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = BengaliNumberUtil.formatNumber(item.gregorianDateStr, lang),
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                        Text(
                            text = BengaliNumberUtil.formatNumber(item.sehriTimeStr, lang),
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = BengaliNumberUtil.formatNumber(item.iftarTimeStr, lang),
                            color = GoldPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        } else {
            // Important Islamic Events List
            items(HijriCalendar.ISLAMIC_EVENTS) { event ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldBorder.copy(alpha = 0.4f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (lang == AppLanguage.BENGALI) event.nameBn else event.nameEn,
                                color = GoldLight,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )

                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = GoldContainer,
                                border = androidx.compose.foundation.BorderStroke(1.dp, GoldBorder)
                            ) {
                                Text(
                                    text = "${BengaliNumberUtil.formatNumber(event.hijriDay, lang)} নং দিন",
                                    color = GoldPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = event.descriptionBn,
                            color = TextSecondary,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        }
    }
}
