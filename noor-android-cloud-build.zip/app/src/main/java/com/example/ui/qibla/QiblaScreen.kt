package com.example.ui.qibla

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.ui.MainViewModel
import com.example.ui.components.IslamicGeometricDivider
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.GoldDeep
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.BengaliNumberUtil
import com.example.util.SensorCompass
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun QiblaScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val homeState by viewModel.homeState.collectAsState()
    val prefs by viewModel.preferences.collectAsState()
    val lang = prefs?.language ?: AppLanguage.BENGALI

    val sensorCompass = remember { SensorCompass(context) }

    // Start/stop sensors with screen lifecycle
    DisposableEffect(Unit) {
        sensorCompass.updateLocation(homeState.location.latitude, homeState.location.longitude)
        sensorCompass.startListening()
        onDispose {
            sensorCompass.stopListening()
        }
    }

    // React to location updates
    DisposableEffect(homeState.location) {
        sensorCompass.updateLocation(homeState.location.latitude, homeState.location.longitude)
        onDispose { }
    }

    val compassState by sensorCompass.compassState.collectAsState()

    // Smooth needle animation
    val animatedNeedleAngle by animateFloatAsState(
        targetValue = compassState.needleAngleDegrees,
        animationSpec = spring(stiffness = 300f),
        label = "qibla_needle_anim"
    )

    val isAligned = abs(compassState.needleAngleDegrees) < 5f || abs(compassState.needleAngleDegrees - 360f) < 5f

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .testTag("qibla_screen"),
        contentPadding = PaddingValues(bottom = 96.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top Header
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurface)
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Column {
                    Text(
                        text = if (lang == AppLanguage.BENGALI) "কিবলা কম্পাস" else "Qibla Compass",
                        color = GoldLight,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${homeState.location.cityName} • কাবার সঠিক দিক নির্দেশনা",
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // Qibla Alignment Banner
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = if (isAligned) EmeraldGreen.copy(alpha = 0.25f) else GoldContainer,
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isAligned) EmeraldLight else GoldBorder
                ),
                modifier = Modifier.padding(horizontal = 24.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (isAligned) EmeraldLight else GoldPrimary)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isAligned) {
                            if (lang == AppLanguage.BENGALI) "✓ আপনি কাবার মুখোমুখি আছেন!" else "✓ You are facing the Kaaba!"
                        } else {
                            if (lang == AppLanguage.BENGALI) "কাবার দিক: ${BengaliNumberUtil.formatNumber(compassState.qiblaAngleDegrees.roundToInt(), lang)}°" else "Qibla Angle: ${compassState.qiblaAngleDegrees.roundToInt()}°"
                        },
                        color = if (isAligned) EmeraldLight else GoldLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Golden Compass Dial
        item {
            Box(
                modifier = Modifier
                    .size(290.dp)
                    .clip(CircleShape)
                    .background(DarkSurface)
                    .border(3.dp, if (isAligned) EmeraldLight else GoldPrimary, CircleShape)
                    .testTag("qibla_compass_dial"),
                contentAlignment = Alignment.Center
            ) {
                // Dial ring drawing
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val center = Offset(size.width / 2, size.height / 2)
                    val radius = size.width / 2 - 12.dp.toPx()

                    // Outer decorative circle
                    drawCircle(
                        color = GoldBorder,
                        radius = radius,
                        center = center,
                        style = Stroke(width = 1.dp.toPx())
                    )

                    // 12 hour ticks
                    for (i in 0 until 360 step 30) {
                        val angleRad = Math.toRadians(i.toDouble() - compassState.deviceAzimuthDegrees)
                        val startR = radius - 8.dp.toPx()
                        val endR = radius
                        val p1 = Offset(
                            (center.x + startR * sin(angleRad)).toFloat(),
                            (center.y - startR * cos(angleRad)).toFloat()
                        )
                        val p2 = Offset(
                            (center.x + endR * sin(angleRad)).toFloat(),
                            (center.y - endR * cos(angleRad)).toFloat()
                        )
                        drawLine(
                            color = if (i % 90 == 0) GoldPrimary else GoldBorder,
                            start = p1,
                            end = p2,
                            strokeWidth = if (i % 90 == 0) 2.5.dp.toPx() else 1.dp.toPx()
                        )
                    }
                }

                // Rotating Needle layer
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .rotate(animatedNeedleAngle),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        // Kaaba pointer icon at the top of the needle
                        Surface(
                            shape = CircleShape,
                            color = if (isAligned) EmeraldGreen else GoldPrimary,
                            border = androidx.compose.foundation.BorderStroke(2.dp, GoldLight),
                            modifier = Modifier
                                .padding(top = 18.dp)
                                .size(42.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "🕋",
                                    fontSize = 20.sp
                                )
                            }
                        }

                        // Needle upper half
                        Box(
                            modifier = Modifier
                                .width(4.dp)
                                .height(70.dp)
                                .background(
                                    Brush.verticalGradient(
                                        listOf(if (isAligned) EmeraldLight else GoldPrimary, GoldDeep)
                                    )
                                )
                        )

                        // Center Pivot
                        Box(
                            modifier = Modifier
                                .size(18.dp)
                                .clip(CircleShape)
                                .background(GoldLight)
                                .border(2.dp, Color.Black, CircleShape)
                        )

                        // Needle lower half
                        Box(
                            modifier = Modifier
                                .width(3.dp)
                                .height(50.dp)
                                .background(Color(0xFF555555))
                        )
                    }
                }

                // Fixed Center Readout
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(top = 110.dp)
                ) {
                    Text(
                        text = "${BengaliNumberUtil.formatNumber(compassState.qiblaAngleDegrees.roundToInt(), lang)}°",
                        color = GoldLight,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (lang == AppLanguage.BENGALI) "কিবলা দিক" else "Qibla Direction",
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                }
            }
        }

        // Distance & Angle Metrics Cards
        item {
            Spacer(modifier = Modifier.height(24.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldBorder.copy(alpha = 0.4f))
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = if (lang == AppLanguage.BENGALI) "মক্কার দূরত্ব" else "Distance to Makkah",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${BengaliNumberUtil.formatNumber(compassState.distanceToMakkahKm.roundToInt(), lang)} কিমি",
                            color = GoldLight,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldBorder.copy(alpha = 0.4f))
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = if (lang == AppLanguage.BENGALI) "ডিভাইস অবস্থান" else "Device Heading",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${BengaliNumberUtil.formatNumber(compassState.deviceAzimuthDegrees.roundToInt(), lang)}°",
                            color = TextPrimary,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Calibration Instructions Card
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldBorder.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Calibration",
                        tint = GoldPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = if (lang == AppLanguage.BENGALI) "কম্পাস ক্যালিব্রেশন নির্দেশিকা" else "Compass Calibration",
                            color = GoldLight,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (lang == AppLanguage.BENGALI) {
                                "সঠিক দিক পেতে আপনার ফোনটি ইংরেজি '8' সংখ্যার মতো কয়েকবার বাতাসে ঘোরান। ধাতব বস্তু ও চৌম্বকীয় কাভার থেকে ডিভাইস দূরে রাখুন।"
                            } else {
                                "To calibrate, wave your phone in a figure-8 motion several times. Keep away from magnetic cases or metal objects."
                            },
                            color = TextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }
    }
}
