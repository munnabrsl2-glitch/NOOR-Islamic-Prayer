package com.example.ui

import android.annotation.SuppressLint
import android.app.Application
import android.location.Geocoder
import android.location.Location
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.NoorApplication
import com.example.data.datastore.UserPreferences
import com.example.data.db.BookmarkEntity
import com.example.data.db.PrayerLogEntity
import com.example.data.model.AdhanAudioOption
import com.example.data.model.AppLanguage
import com.example.data.model.CalculationMethod
import com.example.data.model.JuristicMethod
import com.example.data.model.LocationData
import com.example.data.model.PrayerSchedule
import com.example.data.model.PrayerTimeItem
import com.example.data.model.PrayerType
import com.example.data.prayer.AstronomicalPrayerCalculator
import com.example.data.prayer.HijriCalendar
import com.example.data.prayer.HijriDate
import com.example.data.prayer.PredefinedLocations
import com.example.service.AdhanPlaybackService
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class HomeUiState(
    val currentTimeString: String = "",
    val currentDateGregorianBn: String = "",
    val currentDateGregorianEn: String = "",
    val hijriDate: HijriDate? = null,
    val location: LocationData = PredefinedLocations.DEFAULT_LOCATION,
    val prayerTimes: List<PrayerTimeItem> = emptyList(),
    val nextPrayer: PrayerType = PrayerType.FAJR,
    val nextPrayerTimeFormatted: String = "",
    val countdownSeconds: Long = 0,
    val isAdhanPlaying: Boolean = false,
    val todayLog: PrayerLogEntity = PrayerLogEntity(""),
    val sehriTimeFormatted: String = "",
    val iftarTimeFormatted: String = "",
    val calculationMethodName: String = "",
    val juristicMethodName: String = "",
    val isLocating: Boolean = false,
    val locationErrorMessage: String? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as NoorApplication
    private val repo = app.preferencesRepository
    private val db = app.database
    private val fusedLocationClient = LocationServices.getFusedLocationProviderClient(application)

    val preferences: StateFlow<UserPreferences?> = repo.userPreferencesFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private val _homeState = MutableStateFlow(HomeUiState())
    val homeState: StateFlow<HomeUiState> = _homeState.asStateFlow()

    private val _isTestingAdhan = MutableStateFlow(false)
    val isTestingAdhan: StateFlow<Boolean> = _isTestingAdhan.asStateFlow()

    val recentPrayerLogs = db.prayerLogDao().getRecentLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bookmarks = db.bookmarkDao().getAllBookmarks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private var currentSchedule: PrayerSchedule? = null

    init {
        // Start 1-second live clock & countdown loop
        viewModelScope.launch {
            while (isActive) {
                updateTimeAndCountdown()
                delay(1000)
            }
        }

        // Listen for preference changes and update calculation
        viewModelScope.launch {
            repo.userPreferencesFlow.collect { prefs ->
                calculateTodaySchedule(prefs)
                app.adhanScheduler.scheduleAllUpcomingAlarms()
            }
        }

        // Load today's log
        viewModelScope.launch {
            val todayStr = getTodayDateString()
            db.prayerLogDao().getLogForDate(todayStr).collect { log ->
                _homeState.value = _homeState.value.copy(
                    todayLog = log ?: PrayerLogEntity(todayStr)
                )
            }
        }
    }

    private fun getTodayDateString(): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    }

    fun calculateTodaySchedule(prefs: UserPreferences) {
        val cal = Calendar.getInstance(TimeZone.getTimeZone(prefs.location.timezoneId))
        val schedule = AstronomicalPrayerCalculator.calculateSchedule(
            calendar = cal,
            latitude = prefs.location.latitude,
            longitude = prefs.location.longitude,
            method = prefs.calculationMethod,
            juristicMethod = prefs.juristicMethod,
            fajrAdjustmentMinutes = prefs.fajrAdjustment,
            dhuhrAdjustmentMinutes = prefs.dhuhrAdjustment,
            asrAdjustmentMinutes = prefs.asrAdjustment,
            maghribAdjustmentMinutes = prefs.maghribAdjustment,
            ishaAdjustmentMinutes = prefs.ishaAdjustment
        )
        currentSchedule = schedule

        val hijri = HijriCalendar.getHijriDate(cal, prefs.hijriAdjustment)

        val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault()).apply {
            timeZone = TimeZone.getTimeZone(prefs.location.timezoneId)
        }

        val prayerItems = listOf(
            PrayerTimeItem(
                type = PrayerType.FAJR,
                timeMillis = schedule.fajr,
                timeFormatted = timeFormat.format(schedule.fajr),
                isAdhanEnabled = prefs.fajrEnabled,
                isSilent = prefs.fajrSilent
            ),
            PrayerTimeItem(
                type = PrayerType.SUNRISE,
                timeMillis = schedule.sunrise,
                timeFormatted = timeFormat.format(schedule.sunrise),
                isAdhanEnabled = false,
                isSilent = true
            ),
            PrayerTimeItem(
                type = PrayerType.DHUHR,
                timeMillis = schedule.dhuhr,
                timeFormatted = timeFormat.format(schedule.dhuhr),
                isAdhanEnabled = prefs.dhuhrEnabled,
                isSilent = prefs.dhuhrSilent
            ),
            PrayerTimeItem(
                type = PrayerType.ASR,
                timeMillis = schedule.asr,
                timeFormatted = timeFormat.format(schedule.asr),
                isAdhanEnabled = prefs.asrEnabled,
                isSilent = prefs.asrSilent
            ),
            PrayerTimeItem(
                type = PrayerType.MAGHRIB,
                timeMillis = schedule.maghrib,
                timeFormatted = timeFormat.format(schedule.maghrib),
                isAdhanEnabled = prefs.maghribEnabled,
                isSilent = prefs.maghribSilent
            ),
            PrayerTimeItem(
                type = PrayerType.ISHA,
                timeMillis = schedule.isha,
                timeFormatted = timeFormat.format(schedule.isha),
                isAdhanEnabled = prefs.ishaEnabled,
                isSilent = prefs.ishaSilent
            )
        )

        val gregFormatBn = SimpleDateFormat("EEEE, d MMMM yyyy", Locale("bn", "BD"))
        val gregFormatEn = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.US)

        _homeState.value = _homeState.value.copy(
            location = prefs.location,
            hijriDate = hijri,
            currentDateGregorianBn = gregFormatBn.format(cal.time),
            currentDateGregorianEn = gregFormatEn.format(cal.time),
            prayerTimes = prayerItems,
            sehriTimeFormatted = timeFormat.format(schedule.sehriEnd),
            iftarTimeFormatted = timeFormat.format(schedule.iftarTime),
            calculationMethodName = prefs.calculationMethod.getTitle(prefs.language),
            juristicMethodName = prefs.juristicMethod.getTitle(prefs.language)
        )

        updateTimeAndCountdown()
    }

    private fun updateTimeAndCountdown() {
        val prefs = preferences.value ?: return
        val schedule = currentSchedule ?: return

        val tz = TimeZone.getTimeZone(prefs.location.timezoneId)
        val nowCal = Calendar.getInstance(tz)
        val nowMillis = nowCal.timeInMillis

        val timeFormat = SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).apply {
            timeZone = tz
        }
        val timeDisplay = timeFormat.format(nowCal.time)

        // Find next prayer among 5 daily prayers
        val candidates = listOf(
            PrayerType.FAJR to schedule.fajr,
            PrayerType.DHUHR to schedule.dhuhr,
            PrayerType.ASR to schedule.asr,
            PrayerType.MAGHRIB to schedule.maghrib,
            PrayerType.ISHA to schedule.isha
        )

        var next = candidates.firstOrNull { it.second > nowMillis }
        var diffSec = 0L

        if (next != null) {
            diffSec = (next.second - nowMillis) / 1000
        } else {
            // Next is tomorrow's Fajr
            val tomorrowFajr = schedule.fajr + 24 * 3600 * 1000L
            next = PrayerType.FAJR to tomorrowFajr
            diffSec = (tomorrowFajr - nowMillis) / 1000
        }

        val nextTimeStr = SimpleDateFormat("hh:mm a", Locale.getDefault()).apply {
            timeZone = tz
        }.format(next.second)

        // Update list items to mark upcoming and passed
        val updatedItems = _homeState.value.prayerTimes.map { item ->
            item.copy(
                isNext = item.type == next.first,
                isPassed = item.timeMillis < nowMillis
            )
        }

        _homeState.value = _homeState.value.copy(
            currentTimeString = timeDisplay,
            nextPrayer = next.first,
            nextPrayerTimeFormatted = nextTimeStr,
            countdownSeconds = diffSec.coerceAtLeast(0),
            prayerTimes = updatedItems
        )
    }

    fun togglePrayerCompleted(type: PrayerType) {
        viewModelScope.launch {
            val current = _homeState.value.todayLog
            val updated = when (type) {
                PrayerType.FAJR -> current.copy(fajrDone = !current.fajrDone, updatedAt = System.currentTimeMillis())
                PrayerType.DHUHR -> current.copy(dhuhrDone = !current.dhuhrDone, updatedAt = System.currentTimeMillis())
                PrayerType.ASR -> current.copy(asrDone = !current.asrDone, updatedAt = System.currentTimeMillis())
                PrayerType.MAGHRIB -> current.copy(maghribDone = !current.maghribDone, updatedAt = System.currentTimeMillis())
                PrayerType.ISHA -> current.copy(ishaDone = !current.ishaDone, updatedAt = System.currentTimeMillis())
                PrayerType.SUNRISE -> current.copy(ishraqDone = !current.ishraqDone, updatedAt = System.currentTimeMillis())
            }
            db.prayerLogDao().saveLog(updated)
        }
    }

    fun toggleIshraqCompleted() {
        viewModelScope.launch {
            val current = _homeState.value.todayLog
            val updated = current.copy(ishraqDone = !current.ishraqDone, updatedAt = System.currentTimeMillis())
            db.prayerLogDao().saveLog(updated)
        }
    }

    fun toggleTahajjudCompleted() {
        viewModelScope.launch {
            val current = _homeState.value.todayLog
            val updated = current.copy(tahajjudDone = !current.tahajjudDone, updatedAt = System.currentTimeMillis())
            db.prayerLogDao().saveLog(updated)
        }
    }

    @SuppressLint("MissingPermission")
    fun requestLocationUpdate() {
        _homeState.value = _homeState.value.copy(isLocating = true, locationErrorMessage = null)
        viewModelScope.launch(Dispatchers.IO) {
            try {
                fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
                    if (location != null) {
                        viewModelScope.launch(Dispatchers.IO) {
                            resolveLocationDetails(location.latitude, location.longitude)
                        }
                    } else {
                        _homeState.value = _homeState.value.copy(
                            isLocating = false,
                            locationErrorMessage = "GPS অবস্থান পাওয়া যায়নি। ডিফল্ট শহর ব্যবহার করা হচ্ছে।"
                        )
                    }
                }.addOnFailureListener { e ->
                    _homeState.value = _homeState.value.copy(
                        isLocating = false,
                        locationErrorMessage = "লোকেশন ত্রুটি: ${e.localizedMessage}"
                    )
                }
            } catch (e: Exception) {
                _homeState.value = _homeState.value.copy(
                    isLocating = false,
                    locationErrorMessage = "লোকেশন অনুমতির প্রয়োজন।"
                )
            }
        }
    }

    private suspend fun resolveLocationDetails(lat: Double, lng: Double) {
        var cityName = "আমার অবস্থান"
        var countryName = "বাংলাদেশ"
        var timeZoneId = TimeZone.getDefault().id

        try {
            val geocoder = Geocoder(app, Locale.getDefault())
            @Suppress("DEPRECATION")
            val addresses = geocoder.getFromLocation(lat, lng, 1)
            if (!addresses.isNullOrEmpty()) {
                val addr = addresses[0]
                cityName = addr.locality ?: addr.subAdminArea ?: addr.adminArea ?: "My City"
                countryName = addr.countryName ?: "Country"
            }
        } catch (e: Exception) {
            // Geocoder failure or offline fallback
            cityName = "GPS Location (${String.format(Locale.US, "%.2f, %.2f", lat, lng)})"
        }

        val newLocation = LocationData(
            cityName = cityName,
            countryName = countryName,
            latitude = lat,
            longitude = lng,
            timezoneId = timeZoneId,
            isGps = true
        )

        repo.setLocation(newLocation, isAutoGps = true)
        withContext(Dispatchers.Main) {
            _homeState.value = _homeState.value.copy(isLocating = false)
        }
    }

    fun selectManualCity(city: LocationData) {
        viewModelScope.launch {
            repo.setLocation(city, isAutoGps = false)
        }
    }

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch { repo.setLanguage(language) }
    }

    fun setCalculationMethod(method: CalculationMethod) {
        viewModelScope.launch { repo.setCalculationMethod(method) }
    }

    fun setJuristicMethod(method: JuristicMethod) {
        viewModelScope.launch { repo.setJuristicMethod(method) }
    }

    fun setAdhanAudio(audio: AdhanAudioOption) {
        viewModelScope.launch { repo.setAdhanAudio(audio) }
    }

    fun togglePrayerAdhanEnabled(prayerId: String, enabled: Boolean) {
        viewModelScope.launch { repo.setPrayerAdhanEnabled(prayerId, enabled) }
    }

    fun togglePrayerSilent(prayerId: String, silent: Boolean) {
        viewModelScope.launch { repo.setPrayerSilent(prayerId, silent) }
    }

    fun setPrayerAdjustment(prayerId: String, minutes: Int) {
        viewModelScope.launch { repo.setAdjustment(prayerId, minutes) }
    }

    fun setHijriAdjustment(days: Int) {
        viewModelScope.launch { repo.setHijriAdjustment(days) }
    }

    fun toggleTestAdhan(audioOption: AdhanAudioOption) {
        if (_isTestingAdhan.value) {
            AdhanPlaybackService.stopAdhan(app)
            _isTestingAdhan.value = false
        } else {
            _isTestingAdhan.value = true
            AdhanPlaybackService.startAdhan(
                context = app,
                prayerBn = "পরীক্ষামূলক আজান",
                prayerEn = "Test Adhan",
                audioId = audioOption.id,
                vibrate = true
            )
        }
    }

    fun incrementTasbih() {
        viewModelScope.launch {
            val prefs = preferences.value ?: return@launch
            val nextCount = prefs.tasbihCount + 1
            val nextTotal = prefs.tasbihTotal + 1
            repo.updateTasbih(nextCount, nextTotal)
        }
    }

    fun resetTasbih() {
        viewModelScope.launch {
            val prefs = preferences.value ?: return@launch
            repo.updateTasbih(0, prefs.tasbihTotal)
        }
    }

    fun setTasbihTarget(target: Int) {
        viewModelScope.launch { repo.setTasbihTarget(target) }
    }

    fun setTasbihDhikrIndex(index: Int) {
        viewModelScope.launch { repo.setTasbihDhikrIndex(index) }
    }

    fun toggleTasbihVibrate(enabled: Boolean) {
        viewModelScope.launch { repo.setTasbihVibrate(enabled) }
    }

    fun toggleBookmark(type: String, refId: String, title: String, subtitle: String, arabic: String? = null, trans: String? = null) {
        viewModelScope.launch {
            val existing = db.bookmarkDao().getAllBookmarks()
            // Check if already exists
            val list = db.bookmarkDao().getBookmarksByType(type)
            db.bookmarkDao().deleteByReferenceId(refId)
            // If it wasn't deleted or if user wanted to add, add it
            db.bookmarkDao().insertBookmark(
                BookmarkEntity(
                    type = type,
                    referenceId = refId,
                    title = title,
                    subtitle = subtitle,
                    arabicText = arabic,
                    translation = trans
                )
            )
        }
    }

    fun removeBookmark(refId: String) {
        viewModelScope.launch {
            db.bookmarkDao().deleteByReferenceId(refId)
        }
    }
}
