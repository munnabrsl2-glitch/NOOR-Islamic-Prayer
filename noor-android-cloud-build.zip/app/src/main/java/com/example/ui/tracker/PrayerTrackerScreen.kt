package com.example.ui.tracker

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.PrayerType
import com.example.ui.MainViewModel
import com.example.ui.components.IslamicGeometricDivider
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.BengaliNumberUtil

@Composable
fun PrayerTrackerScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val homeState by viewModel.homeState.collectAsState()
    val prefs by viewModel.preferences.collectAsState()
    val recentLogs by viewModel.recentPrayerLogs.collectAsState()
    val lang = prefs?.language ?: AppLanguage.BENGALI

    val todayLog = homeState.todayLog
    val completedFardCount = todayLog.completedCount()
    val progress = (completedFardCount.toFloat() / 5f).coerceIn(0f, 1f)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .testTag("prayer_tracker_screen"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp)
    ) {
        // Title Header
        item {
            Column(modifier = Modifier.padding(bottom = 16.dp)) {
                Text(
                    text = if (lang == AppLanguage.BENGALI) "নামাজ ট্র্যাকার ও হিসেব" else "Daily Prayer Tracker",
                    color = GoldLight,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (lang == AppLanguage.BENGALI) "আপনার দৈনন্দিন ফরজ ও নফল নামাজের নিয়মিত হিসাব রাখুন" else "Track your 5 daily prayers and voluntary prayers privately",
                    color = TextMuted,
                    fontSize = 12.sp
                )
            }
        }

        // Today's Progress Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = GoldContainer),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (lang == AppLanguage.BENGALI) "আজকের ফরজ নামাজ" else "Today's Fard Prayers",
                                color = GoldLight,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "${BengaliNumberUtil.formatNumber(completedFardCount, lang)} / ${BengaliNumberUtil.formatNumber(5, lang)} ওয়াক্ত আদায়",
                                color = Color.White,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Surface(
                            shape = CircleShape,
                            color = if (completedFardCount == 5) EmeraldGreen else DarkSurface,
                            border = androidx.compose.foundation.BorderStroke(1.5.dp, GoldLight),
                            modifier = Modifier.size(54.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "${(progress * 100).toInt()}%",
                                    color = if (completedFardCount == 5) Color.White else GoldLight,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = GoldPrimary,
                        trackColor = DarkSurfaceVariant
                    )
                }
            }
        }

        // 5 Fard Prayers Checklist
        item {
            Text(
                text = if (lang == AppLanguage.BENGALI) "পাঁচ ওয়াক্ত ফরজ নামাজ" else "Five Daily Prayers",
                color = GoldLight,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = 8.dp)
            )
        }

        val fardList = listOf(
            Triple(PrayerType.FAJR, todayLog.fajrDone, "ফজর (২ রাকাত ফরজ)"),
            Triple(PrayerType.DHUHR, todayLog.dhuhrDone, "যোহর (৪ রাকাত ফরজ)"),
            Triple(PrayerType.ASR, todayLog.asrDone, "আসর (৪ রাকাত ফরজ)"),
            Triple(PrayerType.MAGHRIB, todayLog.maghribDone, "মাগরিব (৩ রাকাত ফরজ)"),
            Triple(PrayerType.ISHA, todayLog.ishaDone, "এশা (৪ রাকাত ফরজ + ৩ বেতের)")
        )

        items(fardList) { (type, isDone, label) ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = if (isDone) DarkSurfaceElevated else DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (isDone) GoldPrimary.copy(alpha = 0.6f) else GoldBorder.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = type.getLocalizedName(lang),
                            color = if (isDone) GoldLight else TextPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = label,
                            color = TextMuted,
                            fontSize = 12.sp
                        )
                    }

                    IconButton(
                        onClick = { viewModel.togglePrayerCompleted(type) },
                        modifier = Modifier.testTag("tracker_check_${type.id}")
                    ) {
                        Icon(
                            imageVector = if (isDone) Icons.Filled.CheckCircle else Icons.Outlined.Circle,
                            contentDescription = "Toggle status",
                            tint = if (isDone) GoldPrimary else TextMuted,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }
            }
        }

        // Voluntary Prayers (Ishraq & Tahajjud)
        item {
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = if (lang == AppLanguage.BENGALI) "নফল ও সুন্নত নামাজ" else "Sunnah & Voluntary Prayers",
                color = GoldLight,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = 8.dp)
            )

            // Ishraq
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldBorder.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (lang == AppLanguage.BENGALI) "ইশরাক / চাশত" else "Ishraq / Duha",
                            color = TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = if (lang == AppLanguage.BENGALI) "সূর্যোদয়ের ২০ মিনিট পর আদায়যোগ্য" else "20 mins after sunrise",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }

                    IconButton(onClick = { viewModel.toggleIshraqCompleted() }) {
                        Icon(
                            imageVector = if (todayLog.ishraqDone) Icons.Filled.CheckCircle else Icons.Outlined.Circle,
                            contentDescription = "Ishraq",
                            tint = if (todayLog.ishraqDone) GoldPrimary else TextMuted
                        )
                    }
                }
            }

            // Tahajjud
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldBorder.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (lang == AppLanguage.BENGALI) "তাহাজ্জুদ সালাত" else "Tahajjud Prayer",
                            color = TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = if (lang == AppLanguage.BENGALI) "রাতের শেষ তৃতীয়াংশের শ্রেষ্ঠ নফল ইবাদত" else "Late night prayer",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }

                    IconButton(onClick = { viewModel.toggleTahajjudCompleted() }) {
                        Icon(
                            imageVector = if (todayLog.tahajjudDone) Icons.Filled.CheckCircle else Icons.Outlined.Circle,
                            contentDescription = "Tahajjud",
                            tint = if (todayLog.tahajjudDone) GoldPrimary else TextMuted
                        )
                    }
                }
            }
        }

        // Recent History Section
        item {
            Spacer(modifier = Modifier.height(18.dp))
            Text(
                text = if (lang == AppLanguage.BENGALI) "বিগত দিনের হিসেব তালিকা" else "Recent History Log",
                color = GoldLight,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = 8.dp)
            )
        }

        if (recentLogs.isEmpty()) {
            item {
                Text(
                    text = if (lang == AppLanguage.BENGALI) "এখনো কোনো অতীত হিসেব নেই। নিয়মিত টিক দিলে এখানে তালিকা প্রদর্শিত হবে।" else "No history records yet.",
                    color = TextMuted,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
            }
        } else {
            items(recentLogs) { log ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(DarkSurfaceVariant)
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                        .padding(bottom = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = log.dateString,
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Text(
                        text = "${BengaliNumberUtil.formatNumber(log.completedCount(), lang)}/৫ আদায়",
                        color = if (log.isAllFardCompleted()) EmeraldLight else GoldLight,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
            }
        }
    }
}
