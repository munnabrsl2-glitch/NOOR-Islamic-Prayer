package com.example.ui.tasbih

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.ui.MainViewModel
import com.example.ui.theme.ArabicFontFamily
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.GoldDeep
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.BengaliNumberUtil

data class DhikrPreset(
    val arabic: String,
    val bn: String,
    val en: String,
    val meaningBn: String
)

val DHIKR_PRESETS = listOf(
    DhikrPreset("سُبْحَانَ اللَّهِ", "সুবহানাল্লাহ", "Subhanallah", "আল্লাহ পরম পবিত্র"),
    DhikrPreset("الْحَمْدُ لِلَّهِ", "আলহামদুলিল্লাহ", "Alhamdulillah", "সমস্ত প্রশংসা আল্লাহর"),
    DhikrPreset("اللَّهُ أَكْبَرُ", "আল্লাহু আকবার", "Allahu Akbar", "আল্লাহ মহান"),
    DhikrPreset("لَا إِلَٰهَ إِلَّا اللَّهُ", "লা ইলাহা ইল্লাল্লাহ", "La ilaha illallah", "আল্লাহ ছাড়া সত্য উপাস্য নেই"),
    DhikrPreset("أَسْتَغْفِرُ اللَّهَ", "আস্তাগফিরুল্লাহ", "Astaghfirullah", "আমি আল্লাহর কাছে ক্ষমা চাই"),
    DhikrPreset("سُبْحَانَ اللَّهِ وَبِحَمْدِهِ", "সুবহানাল্লাহি ওয়া বিহামদিহি", "Subhanallahi wa Bihamdihi", "আল্লাহর প্রশংসাসহ পবিত্রতা ঘোষণা করছি")
)

val TARGET_OPTIONS = listOf(33, 99, 100, 1000)

@Composable
fun TasbihScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val prefs by viewModel.preferences.collectAsState()
    val lang = prefs?.language ?: AppLanguage.BENGALI

    val currentCount = prefs?.tasbihCount ?: 0
    val totalCount = prefs?.tasbihTotal ?: 0L
    val target = prefs?.tasbihTarget ?: 33
    val dhikrIndex = (prefs?.tasbihDhikrIndex ?: 0).coerceIn(0, DHIKR_PRESETS.size - 1)
    val vibrateEnabled = prefs?.tasbihVibrate ?: true

    val activeDhikr = DHIKR_PRESETS[dhikrIndex]

    val progress = (currentCount.toFloat() / target.toFloat()).coerceIn(0f, 1f)
    val animatedProgress by animateFloatAsState(targetValue = progress, label = "tasbih_progress")

    fun triggerVibration(isMilestone: Boolean) {
        if (!vibrateEnabled) return
        val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val duration = if (isMilestone) 180L else 35L
            val amp = if (isMilestone) 255 else 120
            vibrator.vibrate(VibrationEffect.createOneShot(duration, amp))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(if (isMilestone) 180L else 35L)
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .testTag("tasbih_screen"),
        contentPadding = PaddingValues(bottom = 96.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top Header
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurface)
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (lang == AppLanguage.BENGALI) "ডিজিটাল তাসবীহ" else "Digital Tasbih",
                            color = GoldLight,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (lang == AppLanguage.BENGALI) "নিয়মিত জিকির ও ইস্তিগফার" else "Daily Dhikr & Remembrance",
                            color = TextMuted,
                            fontSize = 12.sp
                        )
                    }

                    // Vibrate Toggle
                    IconButton(
                        onClick = { viewModel.toggleTasbihVibrate(!vibrateEnabled) },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Vibration,
                            contentDescription = "Vibrate toggle",
                            tint = if (vibrateEnabled) GoldPrimary else TextMuted
                        )
                    }
                }
            }
        }

        // Dhikr Selector Row
        item {
            Spacer(modifier = Modifier.height(14.dp))
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(DHIKR_PRESETS) { index, item ->
                    FilterChip(
                        selected = index == dhikrIndex,
                        onClick = {
                            viewModel.setTasbihDhikrIndex(index)
                            viewModel.resetTasbih()
                        },
                        label = { Text(item.bn, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = GoldPrimary,
                            selectedLabelColor = Color.Black
                        )
                    )
                }
            }
        }

        // Active Dhikr Display Card
        item {
            Spacer(modifier = Modifier.height(14.dp))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldBorder.copy(alpha = 0.5f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = activeDhikr.arabic,
                        fontFamily = ArabicFontFamily,
                        fontSize = 32.sp,
                        color = GoldLight,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = activeDhikr.bn,
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = activeDhikr.meaningBn,
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // Target Selector Row
        item {
            Spacer(modifier = Modifier.height(14.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (lang == AppLanguage.BENGALI) "টার্গেট সংখ্যা:" else "Target Count:",
                    color = TextSecondary,
                    fontSize = 13.sp
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TARGET_OPTIONS.forEach { opt ->
                        val isSel = opt == target
                        Surface(
                            onClick = { viewModel.setTasbihTarget(opt) },
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSel) GoldPrimary else DarkSurfaceElevated,
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (isSel) GoldLight else GoldBorder)
                        ) {
                            Text(
                                text = BengaliNumberUtil.formatNumber(opt, lang),
                                color = if (isSel) Color.Black else TextSecondary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }

        // Circular Gold Progress & Tap Area
        item {
            Spacer(modifier = Modifier.height(28.dp))
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .clip(CircleShape)
                    .clickable {
                        val next = currentCount + 1
                        val isMilestone = (next % target == 0)
                        triggerVibration(isMilestone)
                        viewModel.incrementTasbih()
                    }
                    .testTag("tasbih_tap_button"),
                contentAlignment = Alignment.Center
            ) {
                // Background Track and Circular Progress Bar
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val stroke = 12.dp.toPx()
                    val diameter = size.minDimension - stroke
                    val topLeft = Offset(stroke / 2, stroke / 2)
                    val arcSize = Size(diameter, diameter)

                    // Track
                    drawArc(
                        color = DarkSurfaceVariant,
                        startAngle = -90f,
                        sweepAngle = 360f,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = stroke)
                    )

                    // Active Progress
                    drawArc(
                        brush = Brush.sweepGradient(
                            listOf(GoldDeep, GoldPrimary, GoldLight)
                        ),
                        startAngle = -90f,
                        sweepAngle = animatedProgress * 360f,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = stroke, cap = StrokeCap.Round)
                    )
                }

                // Inner Tap Sphere
                Box(
                    modifier = Modifier
                        .size(190.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(GoldContainer, DarkSurface)
                            )
                        )
                        .border(2.dp, GoldBorder, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = BengaliNumberUtil.formatNumber(currentCount, lang),
                            fontSize = 46.sp,
                            fontWeight = FontWeight.Bold,
                            color = GoldLight,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "/ ${BengaliNumberUtil.formatNumber(target, lang)}",
                            fontSize = 15.sp,
                            color = TextMuted,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (lang == AppLanguage.BENGALI) "ট্যাপ করুন" else "TAP",
                            fontSize = 11.sp,
                            color = GoldPrimary,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.sp
                        )
                    }
                }
            }
        }

        // Action Buttons: Reset & Lifetime Total
        item {
            Spacer(modifier = Modifier.height(30.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Reset Button
                OutlinedButton(
                    onClick = { viewModel.resetTasbih() },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = GoldLight),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldBorder),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("tasbih_reset_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Reset",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (lang == AppLanguage.BENGALI) "রিসেট" else "Reset",
                        fontWeight = FontWeight.Bold
                    )
                }

                // Total Count Badge
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = DarkSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldBorder.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        horizontalAlignment = Alignment.End
                    ) {
                        Text(
                            text = if (lang == AppLanguage.BENGALI) "সর্বমোট জিকির" else "Total Count",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                        Text(
                            text = BengaliNumberUtil.formatNumber(totalCount, lang),
                            color = GoldLight,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
