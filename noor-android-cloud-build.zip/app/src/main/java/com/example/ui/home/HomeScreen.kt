package com.example.ui.home

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.R
import com.example.data.model.AppLanguage
import com.example.data.model.LocationData
import com.example.data.model.PrayerTimeItem
import com.example.data.model.PrayerType
import com.example.data.prayer.PredefinedLocations
import com.example.ui.MainViewModel
import com.example.ui.components.IslamicGeometricDivider
import com.example.ui.components.PulsingGoldGlow
import com.example.ui.theme.ArabicFontFamily
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.GoldDeep
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldOnContainer
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.BengaliNumberUtil

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val homeState by viewModel.homeState.collectAsState()
    val prefs by viewModel.preferences.collectAsState()
    val context = LocalContext.current

    val lang = prefs?.language ?: AppLanguage.BENGALI

    var showLocationDialog by remember { mutableStateOf(false) }
    var showPermissionRationale by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false
        val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] ?: false
        if (fineGranted || coarseGranted) {
            viewModel.requestLocationUpdate()
        }
    }

    fun requestGpsWithPermission() {
        val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
        val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (fine == PackageManager.PERMISSION_GRANTED || coarse == PackageManager.PERMISSION_GRANTED) {
            viewModel.requestLocationUpdate()
        } else {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .testTag("home_screen_list"),
        contentPadding = PaddingValues(bottom = 96.dp)
    ) {
        // Hero Mosque Banner Header
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(240.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.bg_mosque_gold),
                    contentDescription = "Mosque Night Banner",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )

                // Dark & Gold Vignette Gradient
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Black.copy(alpha = 0.3f),
                                    Color.Black.copy(alpha = 0.7f),
                                    DarkBackground
                                )
                            )
                        )
                )

                // Header Content
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 20.dp, vertical = 16.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Top Row: App Title & Location Selector Chip
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Image(
                                painter = painterResource(id = R.drawable.ic_noor_logo),
                                contentDescription = "NOOR Logo",
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .border(1.dp, GoldPrimary, CircleShape)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "নূর • NOOR",
                                    color = GoldLight,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = if (lang == AppLanguage.BENGALI) "ইসলামিক সালাত ও কুরআন" else "Islamic Prayer & Quran",
                                    color = TextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        // Location Pill
                        Surface(
                            onClick = { showLocationDialog = true },
                            shape = RoundedCornerShape(20.dp),
                            color = DarkSurfaceElevated.copy(alpha = 0.9f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, GoldBorder),
                            modifier = Modifier.testTag("location_selector_chip")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.LocationOn,
                                    contentDescription = "Location",
                                    tint = GoldPrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = homeState.location.cityName.take(15),
                                    color = TextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Spacer(modifier = Modifier.width(2.dp))
                                Icon(
                                    imageVector = Icons.Default.ExpandMore,
                                    contentDescription = "Expand",
                                    tint = GoldLight,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    // Hijri and Gregorian Date Display
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        homeState.hijriDate?.let { hijri ->
                            Text(
                                text = if (lang == AppLanguage.BENGALI) hijri.formattedBn else hijri.formattedEn,
                                color = GoldLight,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold,
                                textAlign = TextAlign.Center
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (lang == AppLanguage.BENGALI) homeState.currentDateGregorianBn else homeState.currentDateGregorianEn,
                            color = TextSecondary,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = BengaliNumberUtil.formatNumber(homeState.currentTimeString, lang),
                            color = Color.White,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }
        }

        // Next Prayer Hero Card
        item {
            Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                PulsingGoldGlow(modifier = Modifier.fillMaxWidth()) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("next_prayer_card"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = GoldContainer)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(18.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = if (lang == AppLanguage.BENGALI) "পরবর্তী সালাতের ওয়াক্ত" else "NEXT PRAYER",
                                        color = GoldLight,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        letterSpacing = 0.5.sp
                                    )
                                    Row(verticalAlignment = Alignment.Bottom) {
                                        Text(
                                            text = homeState.nextPrayer.getLocalizedName(lang),
                                            color = Color.White,
                                            fontSize = 26.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = homeState.nextPrayer.nameAr,
                                            fontFamily = ArabicFontFamily,
                                            color = GoldLight,
                                            fontSize = 20.sp
                                        )
                                    }
                                }

                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = DarkSurface,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldBorder)
                                ) {
                                    Text(
                                        text = BengaliNumberUtil.formatNumber(homeState.nextPrayerTimeFormatted, lang),
                                        color = GoldPrimary,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))
                            IslamicGeometricDivider()
                            Spacer(modifier = Modifier.height(12.dp))

                            // Live Countdown Timer
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(GoldPrimary)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (lang == AppLanguage.BENGALI) "ওয়াক্ত হতে বাকি:" else "Time Remaining:",
                                        color = TextSecondary,
                                        fontSize = 13.sp
                                    )
                                }

                                Text(
                                    text = BengaliNumberUtil.formatDuration(homeState.countdownSeconds, lang),
                                    color = GoldLight,
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Sehri & Iftar Quick Bar
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldBorder.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "🌙 ", fontSize = 16.sp)
                        Column {
                            Text(
                                text = if (lang == AppLanguage.BENGALI) "সেহরির শেষ সময়" else "Sehri Ends",
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                            Text(
                                text = BengaliNumberUtil.formatNumber(homeState.sehriTimeFormatted, lang),
                                color = TextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .height(28.dp)
                            .width(1.dp)
                            .background(GoldBorder.copy(alpha = 0.4f))
                    )

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "☀️ ", fontSize = 16.sp)
                        Column {
                            Text(
                                text = if (lang == AppLanguage.BENGALI) "ইফতারের সময়" else "Iftar Time",
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                            Text(
                                text = BengaliNumberUtil.formatNumber(homeState.iftarTimeFormatted, lang),
                                color = GoldPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Section Title: Today's Prayer Schedule
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (lang == AppLanguage.BENGALI) "আজকের নামাজের সময়সূচি" else "Today's Prayer Times",
                    color = GoldLight,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = if (lang == AppLanguage.BENGALI) "ট্র্যাকার টিক করুন" else "Check off prayer",
                    color = TextMuted,
                    fontSize = 11.sp
                )
            }
        }

        // 5 Daily Prayer Cards
        items(homeState.prayerTimes) { item ->
            val isDone = when (item.type) {
                PrayerType.FAJR -> homeState.todayLog.fajrDone
                PrayerType.DHUHR -> homeState.todayLog.dhuhrDone
                PrayerType.ASR -> homeState.todayLog.asrDone
                PrayerType.MAGHRIB -> homeState.todayLog.maghribDone
                PrayerType.ISHA -> homeState.todayLog.ishaDone
                PrayerType.SUNRISE -> homeState.todayLog.ishraqDone
            }

            PrayerRowCard(
                item = item,
                isDone = isDone,
                lang = lang,
                onToggleDone = { viewModel.togglePrayerCompleted(item.type) },
                onToggleAdhan = {
                    viewModel.togglePrayerAdhanEnabled(item.type.id, !item.isAdhanEnabled)
                }
            )
        }

        // Method & Madhhab Info Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldBorder.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (lang == AppLanguage.BENGALI) "হিসাব পদ্ধতি: ${homeState.calculationMethodName}" else "Method: ${homeState.calculationMethodName}",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                        Text(
                            text = if (lang == AppLanguage.BENGALI) "মাযহাব: ${homeState.juristicMethodName}" else "Madhhab: ${homeState.juristicMethodName}",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }

                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = "Coordinates",
                        tint = GoldPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }

    // Location Selection Dialog
    if (showLocationDialog) {
        LocationSelectionDialog(
            currentLocation = homeState.location,
            isLocating = homeState.isLocating,
            lang = lang,
            onDismiss = { showLocationDialog = false },
            onSelectCity = { city ->
                viewModel.selectManualCity(city)
                showLocationDialog = false
            },
            onDetectGps = {
                requestGpsWithPermission()
            }
        )
    }
}

@Composable
fun PrayerRowCard(
    item: PrayerTimeItem,
    isDone: Boolean,
    lang: AppLanguage,
    onToggleDone: () -> Unit,
    onToggleAdhan: () -> Unit
) {
    val isHighlighted = item.isNext
    val cardBackground = if (isHighlighted) GoldContainer else DarkSurface
    val borderStroke = if (isHighlighted) {
        androidx.compose.foundation.BorderStroke(1.5.dp, GoldPrimary)
    } else {
        androidx.compose.foundation.BorderStroke(1.dp, GoldBorder.copy(alpha = 0.4f))
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .testTag("prayer_row_${item.type.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = cardBackground),
        border = borderStroke
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left: Tracker Checkbox & Prayer Name
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (item.type != PrayerType.SUNRISE) {
                    IconButton(
                        onClick = onToggleDone,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("prayer_done_toggle_${item.type.id}")
                    ) {
                        Icon(
                            imageVector = if (isDone) Icons.Filled.CheckCircle else Icons.Outlined.Circle,
                            contentDescription = "Mark as prayed",
                            tint = if (isDone) GoldPrimary else TextMuted
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                } else {
                    Spacer(modifier = Modifier.width(12.dp))
                }

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = item.type.getLocalizedName(lang),
                            color = if (isHighlighted) GoldLight else TextPrimary,
                            fontSize = 16.sp,
                            fontWeight = if (isHighlighted) FontWeight.Bold else FontWeight.SemiBold
                        )
                        if (isHighlighted) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = GoldPrimary
                            ) {
                                Text(
                                    text = if (lang == AppLanguage.BENGALI) "আসন্ন" else "NEXT",
                                    color = Color.Black,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                    Text(
                        text = item.type.nameAr,
                        fontFamily = ArabicFontFamily,
                        color = TextMuted,
                        fontSize = 13.sp
                    )
                }
            }

            // Right: Time & Adhan Bell Toggle
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = BengaliNumberUtil.formatNumber(item.timeFormatted, lang),
                    color = if (isHighlighted) GoldPrimary else TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                if (item.type != PrayerType.SUNRISE) {
                    Spacer(modifier = Modifier.width(10.dp))
                    IconButton(
                        onClick = onToggleAdhan,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (item.isAdhanEnabled) Icons.Filled.Notifications else Icons.Filled.NotificationsOff,
                            contentDescription = "Toggle Adhan",
                            tint = if (item.isAdhanEnabled) GoldPrimary else TextMuted,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LocationSelectionDialog(
    currentLocation: LocationData,
    isLocating: Boolean,
    lang: AppLanguage,
    onDismiss: () -> Unit,
    onSelectCity: (LocationData) -> Unit,
    onDetectGps: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val allCities = remember { PredefinedLocations.ALL_LOCATIONS }

    val filteredCities = remember(searchQuery) {
        if (searchQuery.isBlank()) allCities else {
            allCities.filter {
                it.cityName.contains(searchQuery, ignoreCase = true) ||
                        it.countryName.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (lang == AppLanguage.BENGALI) "অবস্থান নির্বাচন করুন" else "Select Location",
                color = GoldLight,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Auto GPS Button
                Button(
                    onClick = onDetectGps,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("gps_detect_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                    enabled = !isLocating
                ) {
                    if (isLocating) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            color = Color.Black,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (lang == AppLanguage.BENGALI) "GPS খোঁজা হচ্ছে..." else "Detecting GPS...",
                            color = Color.Black
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.MyLocation,
                            contentDescription = "GPS",
                            tint = Color.Black,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (lang == AppLanguage.BENGALI) "বর্তমান GPS লোকেশন ব্যবহার করুন" else "Use Current GPS Location",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Search City
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("শহর খুঁজুন (e.g. ঢাকা, Sylhet, Makkah)", fontSize = 13.sp) },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = "Search", tint = GoldLight)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("city_search_input"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = GoldBorder
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                // City List
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp)
                ) {
                    items(filteredCities) { city ->
                        val isSelected = city.cityName == currentLocation.cityName
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) GoldContainer else Color.Transparent)
                                .clickable { onSelectCity(city) }
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = city.cityName,
                                    color = if (isSelected) GoldLight else TextPrimary,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = city.countryName,
                                    color = TextMuted,
                                    fontSize = 12.sp
                                )
                            }
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "Selected",
                                    tint = GoldPrimary
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(
                    text = if (lang == AppLanguage.BENGALI) "বন্ধ করুন" else "Close",
                    color = GoldLight
                )
            }
        },
        containerColor = DarkSurfaceElevated
    )
}
