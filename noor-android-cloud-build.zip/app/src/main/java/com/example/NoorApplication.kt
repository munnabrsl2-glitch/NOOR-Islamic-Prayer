package com.example

import android.app.Application
import android.content.Context
import androidx.room.Room
import com.example.data.datastore.UserPreferencesRepository
import com.example.data.db.NoorDatabase
import com.example.service.AdhanScheduler
import com.example.service.NotificationHelper

class NoorApplication : Application() {

    lateinit var database: NoorDatabase
        private set

    lateinit var preferencesRepository: UserPreferencesRepository
        private set

    lateinit var adhanScheduler: AdhanScheduler
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        database = Room.databaseBuilder(
            applicationContext,
            NoorDatabase::class.java,
            "noor_islamic_db"
        ).fallbackToDestructiveMigration().build()

        preferencesRepository = UserPreferencesRepository(applicationContext)

        NotificationHelper.createNotificationChannels(this)
        adhanScheduler = AdhanScheduler(this, preferencesRepository)
    }

    companion object {
        lateinit var instance: NoorApplication
            private set

        fun getAppContext(): Context = instance.applicationContext
    }
}
