package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.NoorApplication
import com.example.service.AdhanPlaybackService
import com.example.service.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class PrayerAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val prayerId = intent?.getStringExtra(EXTRA_PRAYER_ID) ?: return
        val prayerBn = intent.getStringExtra(EXTRA_PRAYER_BN) ?: "নামাজ"
        val prayerEn = intent.getStringExtra(EXTRA_PRAYER_EN) ?: "Prayer"
        val timeFormatted = intent.getStringExtra(EXTRA_TIME_STR) ?: ""

        val app = context.applicationContext as? NoorApplication ?: return
        val repo = app.preferencesRepository

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val prefs = repo.userPreferencesFlow.first()
                val isEnabled = when (prayerId) {
                    "fajr" -> prefs.fajrEnabled
                    "dhuhr" -> prefs.dhuhrEnabled
                    "asr" -> prefs.asrEnabled
                    "maghrib" -> prefs.maghribEnabled
                    "isha" -> prefs.ishaEnabled
                    else -> true
                }

                val isSilent = when (prayerId) {
                    "fajr" -> prefs.fajrSilent
                    "dhuhr" -> prefs.dhuhrSilent
                    "asr" -> prefs.asrSilent
                    "maghrib" -> prefs.maghribSilent
                    "isha" -> prefs.ishaSilent
                    else -> false
                }

                if (isEnabled) {
                    if (isSilent) {
                        NotificationHelper.showSilentPrayerNotification(context, prayerBn, prayerEn, timeFormatted)
                    } else {
                        AdhanPlaybackService.startAdhan(
                            context,
                            prayerBn,
                            prayerEn,
                            prefs.adhanAudio.id,
                            prefs.vibrateEnabled
                        )
                    }
                }

                // Reschedule upcoming alarms
                app.adhanScheduler.scheduleAllUpcomingAlarms()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    companion object {
        const val EXTRA_PRAYER_ID = "prayer_id"
        const val EXTRA_PRAYER_BN = "prayer_bn"
        const val EXTRA_PRAYER_EN = "prayer_en"
        const val EXTRA_TIME_STR = "time_str"
    }
}
