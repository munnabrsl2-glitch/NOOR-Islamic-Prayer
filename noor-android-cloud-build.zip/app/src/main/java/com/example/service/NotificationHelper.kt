package com.example.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R

object NotificationHelper {

    const val CHANNEL_ADHAN = "noor_adhan_channel"
    const val CHANNEL_SILENT = "noor_silent_channel"
    const val CHANNEL_MEDIA = "noor_media_channel"

    const val NOTIFICATION_ID_ADHAN = 1001
    const val NOTIFICATION_ID_MEDIA = 1002

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val adhanChannel = NotificationChannel(
                CHANNEL_ADHAN,
                "Adhan Prayer Alarms (আজান অ্যালার্ম)",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Plays Adhan and shows notification at prayer times"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 200, 500)
            }

            val silentChannel = NotificationChannel(
                CHANNEL_SILENT,
                "Prayer Time Reminders (নামাজের সময় স্মরণিকা)",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Silent visual notification for prayer times"
            }

            val mediaChannel = NotificationChannel(
                CHANNEL_MEDIA,
                "Adhan Audio Playback (আজান অডিও প্লেয়ার)",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows playback controls while Adhan is playing"
            }

            notificationManager.createNotificationChannels(listOf(adhanChannel, silentChannel, mediaChannel))
        }
    }

    fun showSilentPrayerNotification(context: Context, prayerNameBn: String, prayerNameEn: String, timeFormatted: String) {
        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_SILENT)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("ওয়াক্ত শুরু: $prayerNameBn ($prayerNameEn)")
            .setContentText("এখন $prayerNameBn নামাজের ওয়াক্ত। সময়: $timeFormatted")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID_ADHAN, notification)
    }
}
