package com.example.service

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.data.datastore.UserPreferencesRepository
import com.example.data.model.PrayerType
import com.example.data.prayer.AstronomicalPrayerCalculator
import com.example.receiver.PrayerAlarmReceiver
import kotlinx.coroutines.flow.first
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

class AdhanScheduler(
    private val context: Context,
    private val preferencesRepository: UserPreferencesRepository
) {

    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager

    fun canScheduleExactAlarms(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            alarmManager?.canScheduleExactAlarms() ?: false
        } else {
            true
        }
    }

    suspend fun scheduleAllUpcomingAlarms() {
        val prefs = preferencesRepository.userPreferencesFlow.first()
        val loc = prefs.location
        val tz = TimeZone.getTimeZone(loc.timezoneId)

        val now = System.currentTimeMillis()

        // Schedule for today and tomorrow
        for (dayOffset in 0..1) {
            val cal = Calendar.getInstance(tz).apply {
                add(Calendar.DAY_OF_YEAR, dayOffset)
            }

            val schedule = AstronomicalPrayerCalculator.calculateSchedule(
                calendar = cal,
                latitude = loc.latitude,
                longitude = loc.longitude,
                method = prefs.calculationMethod,
                juristicMethod = prefs.juristicMethod,
                fajrAdjustmentMinutes = prefs.fajrAdjustment,
                dhuhrAdjustmentMinutes = prefs.dhuhrAdjustment,
                asrAdjustmentMinutes = prefs.asrAdjustment,
                maghribAdjustmentMinutes = prefs.maghribAdjustment,
                ishaAdjustmentMinutes = prefs.ishaAdjustment
            )

            val prayerTimes = listOf(
                Triple(PrayerType.FAJR, schedule.fajr, prefs.fajrEnabled),
                Triple(PrayerType.DHUHR, schedule.dhuhr, prefs.dhuhrEnabled),
                Triple(PrayerType.ASR, schedule.asr, prefs.asrEnabled),
                Triple(PrayerType.MAGHRIB, schedule.maghrib, prefs.maghribEnabled),
                Triple(PrayerType.ISHA, schedule.isha, prefs.ishaEnabled)
            )

            val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault()).apply {
                timeZone = tz
            }

            for ((type, timeMillis, isEnabled) in prayerTimes) {
                if (isEnabled && timeMillis > now) {
                    scheduleExactAlarm(
                        prayerType = type,
                        timeMillis = timeMillis,
                        timeFormatted = timeFormat.format(timeMillis)
                    )
                }
            }
        }
    }

    private fun scheduleExactAlarm(
        prayerType: PrayerType,
        timeMillis: Long,
        timeFormatted: String
    ) {
        val am = alarmManager ?: return
        val requestCode = prayerType.ordinal + 100

        val intent = Intent(context, PrayerAlarmReceiver::class.java).apply {
            putExtra(PrayerAlarmReceiver.EXTRA_PRAYER_ID, prayerType.id)
            putExtra(PrayerAlarmReceiver.EXTRA_PRAYER_BN, prayerType.nameBn)
            putExtra(PrayerAlarmReceiver.EXTRA_PRAYER_EN, prayerType.nameEn)
            putExtra(PrayerAlarmReceiver.EXTRA_TIME_STR, timeFormatted)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timeMillis, pendingIntent)
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, timeMillis, pendingIntent)
            }
        } catch (e: SecurityException) {
            // If exact alarm permission not granted on Android 12+, fall back to inexact
            am.set(AlarmManager.RTC_WAKEUP, timeMillis, pendingIntent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun cancelAllAlarms() {
        val am = alarmManager ?: return
        PrayerType.entries.forEach { type ->
            val requestCode = type.ordinal + 100
            val intent = Intent(context, PrayerAlarmReceiver::class.java)
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                requestCode,
                intent,
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pendingIntent != null) {
                am.cancel(pendingIntent)
            }
        }
    }
}
