package com.example.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.model.AdhanAudioOption

class AdhanPlaybackService : Service() {

    private var mediaPlayer: MediaPlayer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var audioManager: AudioManager? = null
    private var focusRequest: AudioFocusRequest? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Noor::AdhanWakeLock").apply {
            acquire(5 * 60 * 1000L) // 5 minutes max
        }
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP) {
            stopAdhan()
            return START_NOT_STICKY
        }

        val prayerNameBn = intent?.getStringExtra(EXTRA_PRAYER_NAME_BN) ?: "নামাজ"
        val prayerNameEn = intent?.getStringExtra(EXTRA_PRAYER_NAME_EN) ?: "Prayer"
        val audioId = intent?.getStringExtra(EXTRA_AUDIO_ID) ?: "makkah"
        val shouldVibrate = intent?.getBooleanExtra(EXTRA_VIBRATE, true) ?: true

        startForeground(NotificationHelper.NOTIFICATION_ID_MEDIA, buildAdhanNotification(prayerNameBn, prayerNameEn))

        playAdhan(audioId, shouldVibrate)

        return START_NOT_STICKY
    }

    private fun playAdhan(audioId: String, shouldVibrate: Boolean) {
        stopAdhanPlaybackOnly()

        val rawResId = when (AdhanAudioOption.fromId(audioId)) {
            AdhanAudioOption.MAKKAH -> R.raw.adhan_makkah
            AdhanAudioOption.MADINAH -> R.raw.adhan_madinah
            AdhanAudioOption.SHORT -> R.raw.adhan_short
        }

        try {
            requestAudioFocus()

            mediaPlayer = MediaPlayer.create(this, rawResId)?.apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .build()
                )
                setOnCompletionListener {
                    stopAdhan()
                }
                setOnErrorListener { _, _, _ ->
                    stopAdhan()
                    true
                }
                start()
            }

            if (shouldVibrate) {
                val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                @Suppress("DEPRECATION")
                vibrator?.vibrate(longArrayOf(0, 800, 400, 800), -1)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            stopAdhan()
        }
    }

    private fun requestAudioFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val playbackAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            focusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(playbackAttributes)
                .build()
            focusRequest?.let { am.requestAudioFocus(it) }
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(null, AudioManager.STREAM_ALARM, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
        }
    }

    private fun abandonAudioFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            focusRequest?.let { am.abandonAudioFocusRequest(it) }
        } else {
            @Suppress("DEPRECATION")
            am.abandonAudioFocus(null)
        }
    }

    private fun buildAdhanNotification(prayerBn: String, prayerEn: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            this,
            1,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, AdhanPlaybackService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            2,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, NotificationHelper.CHANNEL_ADHAN)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("ওয়াক্ত শুরু: $prayerBn ($prayerEn)")
            .setContentText("আজানের পবিত্র ধ্বনি বাজছে... (আল্লাহু আকবার)")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setOngoing(true)
            .setContentIntent(openPendingIntent)
            .addAction(android.R.drawable.ic_media_pause, "আজান বন্ধ করুন (Stop)", stopPendingIntent)
            .build()
    }

    private fun stopAdhanPlaybackOnly() {
        try {
            mediaPlayer?.let {
                if (it.isPlaying) {
                    it.stop()
                }
                it.release()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        mediaPlayer = null
        abandonAudioFocus()
    }

    private fun stopAdhan() {
        stopAdhanPlaybackOnly()
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopAdhanPlaybackOnly()
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.example.action.START_ADHAN"
        const val ACTION_STOP = "com.example.action.STOP_ADHAN"

        const val EXTRA_PRAYER_NAME_BN = "extra_prayer_bn"
        const val EXTRA_PRAYER_NAME_EN = "extra_prayer_en"
        const val EXTRA_AUDIO_ID = "extra_audio_id"
        const val EXTRA_VIBRATE = "extra_vibrate"

        fun startAdhan(context: Context, prayerBn: String, prayerEn: String, audioId: String, vibrate: Boolean) {
            val intent = Intent(context, AdhanPlaybackService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_PRAYER_NAME_BN, prayerBn)
                putExtra(EXTRA_PRAYER_NAME_EN, prayerEn)
                putExtra(EXTRA_AUDIO_ID, audioId)
                putExtra(EXTRA_VIBRATE, vibrate)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopAdhan(context: Context) {
            val intent = Intent(context, AdhanPlaybackService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }
}
