package com.example.data.prayer

import com.example.data.model.AppLanguage
import java.util.Calendar
import kotlin.math.floor

data class HijriDate(
    val day: Int,
    val month: Int,
    val year: Int,
    val monthNameEn: String,
    val monthNameBn: String,
    val monthNameAr: String,
    val formattedBn: String,
    val formattedEn: String
)

data class IslamicEvent(
    val hijriMonth: Int,
    val hijriDay: Int,
    val nameEn: String,
    val nameBn: String,
    val descriptionBn: String
)

object HijriCalendar {

    private val MONTH_NAMES_EN = arrayOf(
        "Muharram", "Safar", "Rabi' al-Awwal", "Rabi' al-Thani",
        "Jumada al-Awwal", "Jumada al-Thani", "Rajab", "Sha'ban",
        "Ramadan", "Shawwal", "Dhu al-Qi'dah", "Dhu al-Hijjah"
    )

    private val MONTH_NAMES_BN = arrayOf(
        "মুহররম", "সফর", "রবিউল আউয়াল", "রবিউস সানি",
        "জুমাদিউল আউয়াল", "জুমাদিউস সানি", "রজব", "শাবান",
        "রমজান", "শাওয়াল", "জিলক্বদ", "জিলহজ্জ"
    )

    private val MONTH_NAMES_AR = arrayOf(
        "محرم", "صفر", "ربيع الأول", "ربيع الثاني",
        "جمادى الأولى", "جمادى الآخرة", "رجب", "شعبان",
        "رمضان", "شوال", "ذو القعدة", "ذو الحجة"
    )

    val ISLAMIC_EVENTS = listOf(
        IslamicEvent(1, 1, "Islamic New Year", "হিজরি নববর্ষ", "পবিত্র হিজরি সনের প্রথম দিন"),
        IslamicEvent(1, 10, "Day of Ashura", "পবিত্র আশুরা", "হজরত মুসা (আ.) ও কারবালার ঐতিহাসিক স্মৃতিবিজড়িত দিন"),
        IslamicEvent(3, 12, "Eid-e-Miladunnabi (PBUH)", "ঈদে মিলাদুন্নবী (সা.)", "মহানবী হযরত মুহাম্মদ (সা.)-এর পবিত্র বেলাদত ও ওফাত দিবস"),
        IslamicEvent(7, 27, "Shab-e-Meraj", "পবিত্র শবে মেরাজ", "মহানবীর ঊর্ধ্বাকাশ গমন ও সালাত প্রাপ্তির রজনী"),
        IslamicEvent(8, 15, "Shab-e-Barat", "পবিত্র শবে বরাত", "লাইলাতুল বরাত বা ভাগ্য ও ক্ষমার মহিমান্বিত রাত"),
        IslamicEvent(9, 1, "First Day of Ramadan", "১ম রমজান (রোজা শুরু)", "রহমত, মাগফিরাত ও নাজাতের পবিত্র মাস সূচনা"),
        IslamicEvent(9, 27, "Laylat al-Qadr", "পবিত্র শবে কদর", "হাজার মাসের চেয়েও উত্তম ও বরকতময় পবিত্র রাত"),
        IslamicEvent(10, 1, "Eid-ul-Fitr", "ঈদুল ফিতর", "দীর্ঘ এক মাস সিয়াম সাধনার পর আনন্দের মহোৎসব"),
        IslamicEvent(12, 9, "Day of Arafah", "আরাফাত দিবস", "পবিত্র হজের মূল আনুষ্ঠানিকতা ও ক্ষমার দিবস"),
        IslamicEvent(12, 10, "Eid-ul-Adha", "ঈদুল আজহা", "কুরবানির পবিত্র ঈদ ও হজরত ইব্রাহিম (আ.)-এর ত্যাগ")
    )

    fun getHijriDate(calendar: Calendar, dayAdjustment: Int = 0): HijriDate {
        val y = calendar.get(Calendar.YEAR)
        val m = calendar.get(Calendar.MONTH) + 1
        val d = calendar.get(Calendar.DAY_OF_MONTH)

        // Julian Day Number
        var a = floor((14 - m) / 12.0).toInt()
        var year = y + 4800 - a
        var month = m + 12 * a - 3
        var jdn = d + floor((153 * month + 2) / 5.0).toInt() + 365 * year + floor(year / 4.0).toInt() -
                floor(year / 100.0).toInt() + floor(year / 400.0).toInt() - 32045

        jdn += dayAdjustment

        // Algorithmic conversion to Islamic Lunar calendar (Kuwaiti algorithm variant)
        val l = jdn - 1948440 + 10632
        val n = floor((l - 1) / 10631.0).toInt()
        val lPrime = l - 10631 * n + 354
        val j = (floor((10985 - lPrime) / 5316.0) * floor((50 * lPrime) / 17719.0) +
                floor(lPrime / 5670.0) * floor((43 * lPrime) / 15238.0)).toInt()
        val lDoublePrime = lPrime - (floor((30 - j) / 15.0) * floor((17719 * j) / 50.0) +
                floor(j / 16.0) * floor((15238 * j) / 43.0)).toInt() + 29
        val hMonth = floor((24 * lDoublePrime) / 709.0).toInt()
        val hDay = lDoublePrime - floor((709 * hMonth) / 24.0).toInt()
        val hYear = 30 * n + j - 30

        val safeMonth = ((hMonth - 1) % 12 + 12) % 12
        val safeDay = hDay.coerceIn(1, 30)

        val mEn = MONTH_NAMES_EN[safeMonth]
        val mBn = MONTH_NAMES_BN[safeMonth]
        val mAr = MONTH_NAMES_AR[safeMonth]

        fun toBnDigits(num: Int): String {
            val bnDigits = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')
            return num.toString().map { if (it in '0'..'9') bnDigits[it - '0'] else it }.joinToString("")
        }

        val formattedBn = "${toBnDigits(safeDay)} $mBn, ${toBnDigits(hYear)} হিজরি"
        val formattedEn = "$safeDay $mEn $hYear AH"

        return HijriDate(
            day = safeDay,
            month = safeMonth + 1,
            year = hYear,
            monthNameEn = mEn,
            monthNameBn = mBn,
            monthNameAr = mAr,
            formattedBn = formattedBn,
            formattedEn = formattedEn
        )
    }
}
