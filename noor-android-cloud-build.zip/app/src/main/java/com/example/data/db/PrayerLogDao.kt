package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PrayerLogDao {

    @Query("SELECT * FROM prayer_logs WHERE dateString = :dateString")
    fun getLogForDate(dateString: String): Flow<PrayerLogEntity?>

    @Query("SELECT * FROM prayer_logs WHERE dateString = :dateString")
    suspend fun getLogDirect(dateString: String): PrayerLogEntity?

    @Query("SELECT * FROM prayer_logs ORDER BY dateString DESC LIMIT 30")
    fun getRecentLogs(): Flow<List<PrayerLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveLog(log: PrayerLogEntity)

    @Query("SELECT COUNT(*) FROM prayer_logs WHERE fajrDone = 1 AND dhuhrDone = 1 AND asrDone = 1 AND maghribDone = 1 AND ishaDone = 1")
    fun getFullPrayerDaysCount(): Flow<Int>
}
