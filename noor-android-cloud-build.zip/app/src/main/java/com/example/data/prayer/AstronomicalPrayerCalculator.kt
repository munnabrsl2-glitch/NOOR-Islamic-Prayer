package com.example.data.prayer

import com.example.data.model.CalculationMethod
import com.example.data.model.JuristicMethod
import com.example.data.model.PrayerSchedule
import java.util.Calendar
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

object AstronomicalPrayerCalculator {

    private fun d2r(d: Double): Double = Math.toRadians(d)
    private fun r2d(r: Double): Double = Math.toDegrees(r)
    private fun fixAngle(a: Double): Double = a - 360.0 * floor(a / 360.0)
    private fun fixHour(a: Double): Double = a - 24.0 * floor(a / 24.0)

    data class SolarCoords(
        val declination: Double,
        val equationOfTime: Double
    )

    private fun computeSolarCoords(julianDay: Double): SolarCoords {
        val d = julianDay - 2451545.0
        val g = fixAngle(357.529 + 0.98560028 * d)
        val q = fixAngle(280.459 + 0.98564736 * d)
        val l = fixAngle(q + 1.915 * sin(d2r(g)) + 0.020 * sin(d2r(2 * g)))
        val e = 23.439 - 0.00000036 * d
        val ra = fixHour(r2d(atan2(cos(d2r(e)) * sin(d2r(l)), cos(d2r(l)))) / 15.0)
        val eqT = q / 15.0 - ra
        val decl = r2d(asin(sin(d2r(e)) * sin(d2r(l))))
        return SolarCoords(decl, eqT)
    }

    private fun julianDate(year: Int, month: Int, day: Int): Double {
        var y = year
        var m = month
        if (m <= 2) {
            y -= 1
            m += 12
        }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + day + b - 1524.5
    }

    fun calculateSchedule(
        calendar: Calendar,
        latitude: Double,
        longitude: Double,
        elevationMeters: Double = 10.0,
        method: CalculationMethod = CalculationMethod.BANGLADESH,
        juristicMethod: JuristicMethod = JuristicMethod.HANAFI,
        fajrAdjustmentMinutes: Int = 0,
        dhuhrAdjustmentMinutes: Int = 0,
        asrAdjustmentMinutes: Int = 0,
        maghribAdjustmentMinutes: Int = 0,
        ishaAdjustmentMinutes: Int = 0
    ): PrayerSchedule {
        val tz = calendar.timeZone
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH) + 1
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val jd = julianDate(year, month, day)
        val solar = computeSolarCoords(jd)

        // Timezone offset in hours
        val calAtNoon = (calendar.clone() as Calendar).apply {
            set(Calendar.HOUR_OF_DAY, 12)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val tzOffsetHours = tz.getOffset(calAtNoon.timeInMillis) / 3600000.0

        // Solar noon (transit) in hours
        val transit = fixHour(12.0 + tzOffsetHours - (longitude / 15.0) - solar.equationOfTime)

        // Sun altitude angle for sunrise / sunset: -0.8333 - 0.0347 * sqrt(elevation)
        val sunsetAngle = -0.8333 - 0.0347 * sqrt(elevationMeters.coerceAtLeast(0.0))

        fun sunHourAngle(angle: Double): Double {
            val sinAngle = sin(d2r(angle))
            val sinLat = sin(d2r(latitude))
            val cosLat = cos(d2r(latitude))
            val sinDecl = sin(d2r(solar.declination))
            val cosDecl = cos(d2r(solar.declination))
            val cosH = (sinAngle - sinLat * sinDecl) / (cosLat * cosDecl)
            return if (cosH < -1.0) 180.0 else if (cosH > 1.0) 0.0 else r2d(acos(cosH))
        }

        fun asrHourAngle(shadowFactor: Double): Double {
            val d = abs(latitude - solar.declination)
            val cotAngle = shadowFactor + tan(d2r(d))
            val asrAngle = r2d(atan(1.0 / cotAngle))
            return sunHourAngle(asrAngle)
        }

        val hRiseSet = sunHourAngle(sunsetAngle)
        val sunriseHour = transit - (hRiseSet / 15.0)
        val sunsetHour = transit + (hRiseSet / 15.0)

        val hFajr = sunHourAngle(-method.fajrAngle)
        val fajrHour = transit - (hFajr / 15.0)

        val dhuhrHour = transit + (1.0 / 60.0) // 1 minute after true zenith

        val hAsr = asrHourAngle(juristicMethod.shadowFactor)
        val asrHour = transit + (hAsr / 15.0)

        val maghribHour = sunsetHour + (2.0 / 60.0) // 2 min safety dip

        val ishaHour = if (method.ishaMinutesAfterMaghrib != null) {
            maghribHour + (method.ishaMinutesAfterMaghrib / 60.0)
        } else {
            val hIsha = sunHourAngle(-method.ishaAngle)
            transit + (hIsha / 15.0)
        }

        fun hourToMillis(hour: Double, adjustMinutes: Int): Long {
            val totalSeconds = ((fixHour(hour) * 3600.0) + (adjustMinutes * 60.0)).toLong()
            val c = (calendar.clone() as Calendar).apply {
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                add(Calendar.SECOND, totalSeconds.toInt())
            }
            return c.timeInMillis
        }

        val fajrMillis = hourToMillis(fajrHour, fajrAdjustmentMinutes)
        val sunriseMillis = hourToMillis(sunriseHour, 0)
        val dhuhrMillis = hourToMillis(dhuhrHour, dhuhrAdjustmentMinutes)
        val asrMillis = hourToMillis(asrHour, asrAdjustmentMinutes)
        val maghribMillis = hourToMillis(maghribHour, maghribAdjustmentMinutes)
        val ishaMillis = hourToMillis(ishaHour, ishaAdjustmentMinutes)

        // Islamic midnight and Tahajjud (last third of the night between Maghrib and Fajr of next day)
        val nightDuration = (fajrMillis + 24 * 3600 * 1000L) - maghribMillis
        val midnightMillis = maghribMillis + (nightDuration / 2)
        val tahajjudMillis = (fajrMillis + 24 * 3600 * 1000L) - (nightDuration / 3)

        val startOfDay = (calendar.clone() as Calendar).apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        return PrayerSchedule(
            dateEpochDays = startOfDay / (24 * 3600 * 1000L),
            fajr = fajrMillis,
            sunrise = sunriseMillis,
            dhuhr = dhuhrMillis,
            asr = asrMillis,
            maghrib = maghribMillis,
            isha = ishaMillis,
            sehriEnd = fajrMillis,
            iftarTime = maghribMillis,
            midnight = midnightMillis,
            tahajjudLastThird = tahajjudMillis
        )
    }
}
