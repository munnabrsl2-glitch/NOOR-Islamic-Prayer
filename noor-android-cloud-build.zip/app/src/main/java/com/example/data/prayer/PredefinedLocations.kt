package com.example.data.prayer

import com.example.data.model.LocationData

object PredefinedLocations {

    val DEFAULT_LOCATION = LocationData(
        cityName = "Dhaka",
        countryName = "Bangladesh",
        latitude = 23.8103,
        longitude = 90.4125,
        timezoneId = "Asia/Dhaka",
        isGps = false
    )

    val BANGLADESH_CITIES = listOf(
        LocationData("Dhaka (ঢাকা)", "Bangladesh", 23.8103, 90.4125, "Asia/Dhaka"),
        LocationData("Chittagong (চট্টগ্রাম)", "Bangladesh", 22.3569, 91.7832, "Asia/Dhaka"),
        LocationData("Sylhet (সিলেট)", "Bangladesh", 24.8949, 91.8687, "Asia/Dhaka"),
        LocationData("Rajshahi (রাজশাহী)", "Bangladesh", 24.3745, 88.6042, "Asia/Dhaka"),
        LocationData("Khulna (খুলনা)", "Bangladesh", 22.8456, 89.5403, "Asia/Dhaka"),
        LocationData("Barisal (বরিশাল)", "Bangladesh", 22.7010, 90.3535, "Asia/Dhaka"),
        LocationData("Rangpur (রংপুর)", "Bangladesh", 25.7439, 89.2752, "Asia/Dhaka"),
        LocationData("Mymensingh (ময়মনসিংহ)", "Bangladesh", 24.7471, 90.4203, "Asia/Dhaka"),
        LocationData("Comilla (কুমিল্লা)", "Bangladesh", 23.4682, 91.1788, "Asia/Dhaka"),
        LocationData("Cox's Bazar (কক্সবাজার)", "Bangladesh", 21.4272, 92.0058, "Asia/Dhaka"),
        LocationData("Bogra (বগুড়া)", "Bangladesh", 24.8465, 89.3777, "Asia/Dhaka"),
        LocationData("Jessore (যশোর)", "Bangladesh", 23.1664, 89.2081, "Asia/Dhaka"),
        LocationData("Dinajpur (দিনাজপুর)", "Bangladesh", 25.6217, 88.6355, "Asia/Dhaka"),
        LocationData("Narayanganj (নারায়ণগঞ্জ)", "Bangladesh", 23.6238, 90.5000, "Asia/Dhaka"),
        LocationData("Gazipur (গাজীপুর)", "Bangladesh", 23.9999, 90.4203, "Asia/Dhaka")
    )

    val INTERNATIONAL_CITIES = listOf(
        LocationData("Makkah (مكة المكرمة)", "Saudi Arabia", 21.4225, 39.8262, "Asia/Riyadh"),
        LocationData("Madinah (المدينة المنورة)", "Saudi Arabia", 24.4672, 39.6111, "Asia/Riyadh"),
        LocationData("Jerusalem / Al-Quds (القدس)", "Palestine", 31.7683, 35.2137, "Asia/Jerusalem"),
        LocationData("Dubai (دبي)", "UAE", 25.2048, 55.2708, "Asia/Dubai"),
        LocationData("Istanbul (İstanbul)", "Turkey", 41.0082, 28.9784, "Europe/Istanbul"),
        LocationData("Cairo (القاهرة)", "Egypt", 30.0444, 31.2357, "Africa/Cairo"),
        LocationData("Kuala Lumpur", "Malaysia", 3.1390, 101.6869, "Asia/Kuala_Lumpur"),
        LocationData("Jakarta", "Indonesia", -6.2088, 106.8456, "Asia/Jakarta"),
        LocationData("Karachi", "Pakistan", 24.8607, 67.0011, "Asia/Karachi"),
        LocationData("London", "United Kingdom", 51.5074, -0.1278, "Europe/London"),
        LocationData("New York", "USA", 40.7128, -74.0060, "America/New_York"),
        LocationData("Toronto", "Canada", 43.6532, -79.3832, "America/Toronto"),
        LocationData("Sydney", "Australia", -33.8688, 151.2093, "Australia/Sydney")
    )

    val ALL_LOCATIONS: List<LocationData> = BANGLADESH_CITIES + INTERNATIONAL_CITIES
}
