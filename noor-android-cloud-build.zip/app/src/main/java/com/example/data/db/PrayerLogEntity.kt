package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "prayer_logs")
data class PrayerLogEntity(
    @PrimaryKey
    val dateString: String, // Format: YYYY-MM-DD
    val fajrDone: Boolean = false,
    val dhuhrDone: Boolean = false,
    val asrDone: Boolean = false,
    val maghribDone: Boolean = false,
    val ishaDone: Boolean = false,
    val ishraqDone: Boolean = false,
    val tahajjudDone: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun completedCount(): Int {
        var count = 0
        if (fajrDone) count++
        if (dhuhrDone) count++
        if (asrDone) count++
        if (maghribDone) count++
        if (ishaDone) count++
        return count
    }

    fun isAllFardCompleted(): Boolean = fajrDone && dhuhrDone && asrDone && maghribDone && ishaDone
}
