package com.example.data.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.AdhanAudioOption
import com.example.data.model.AppLanguage
import com.example.data.model.CalculationMethod
import com.example.data.model.JuristicMethod
import com.example.data.model.LocationData
import com.example.data.prayer.PredefinedLocations
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "noor_user_preferences")

data class UserPreferences(
    val language: AppLanguage,
    val calculationMethod: CalculationMethod,
    val juristicMethod: JuristicMethod,
    val location: LocationData,
    val isAutoGps: Boolean,
    val adhanAudio: AdhanAudioOption,
    val fajrEnabled: Boolean,
    val dhuhrEnabled: Boolean,
    val asrEnabled: Boolean,
    val maghribEnabled: Boolean,
    val ishaEnabled: Boolean,
    val fajrSilent: Boolean,
    val dhuhrSilent: Boolean,
    val asrSilent: Boolean,
    val maghribSilent: Boolean,
    val ishaSilent: Boolean,
    val vibrateEnabled: Boolean,
    val fajrAdjustment: Int,
    val dhuhrAdjustment: Int,
    val asrAdjustment: Int,
    val maghribAdjustment: Int,
    val ishaAdjustment: Int,
    val hijriAdjustment: Int,
    val tasbihCount: Int,
    val tasbihTotal: Long,
    val tasbihTarget: Int,
    val tasbihDhikrIndex: Int,
    val tasbihVibrate: Boolean
)

class UserPreferencesRepository(private val context: Context) {

    private object PreferencesKeys {
        val KEY_LANGUAGE = stringPreferencesKey("app_language")
        val KEY_CALC_METHOD = stringPreferencesKey("calc_method")
        val KEY_JURISTIC_METHOD = stringPreferencesKey("juristic_method")
        val KEY_CITY_NAME = stringPreferencesKey("city_name")
        val KEY_COUNTRY_NAME = stringPreferencesKey("country_name")
        val KEY_LATITUDE = doublePreferencesKey("latitude")
        val KEY_LONGITUDE = doublePreferencesKey("longitude")
        val KEY_TIMEZONE = stringPreferencesKey("timezone")
        val KEY_AUTO_GPS = booleanPreferencesKey("auto_gps")

        val KEY_ADHAN_AUDIO = stringPreferencesKey("adhan_audio")
        val KEY_FAJR_ENABLED = booleanPreferencesKey("fajr_adhan_enabled")
        val KEY_DHUHR_ENABLED = booleanPreferencesKey("dhuhr_adhan_enabled")
        val KEY_ASR_ENABLED = booleanPreferencesKey("asr_adhan_enabled")
        val KEY_MAGHRIB_ENABLED = booleanPreferencesKey("maghrib_adhan_enabled")
        val KEY_ISHA_ENABLED = booleanPreferencesKey("isha_adhan_enabled")

        val KEY_FAJR_SILENT = booleanPreferencesKey("fajr_silent")
        val KEY_DHUHR_SILENT = booleanPreferencesKey("dhuhr_silent")
        val KEY_ASR_SILENT = booleanPreferencesKey("asr_silent")
        val KEY_MAGHRIB_SILENT = booleanPreferencesKey("maghrib_silent")
        val KEY_ISHA_SILENT = booleanPreferencesKey("isha_silent")
        val KEY_VIBRATE = booleanPreferencesKey("vibrate_enabled")

        val KEY_FAJR_ADJ = intPreferencesKey("fajr_adj")
        val KEY_DHUHR_ADJ = intPreferencesKey("dhuhr_adj")
        val KEY_ASR_ADJ = intPreferencesKey("asr_adj")
        val KEY_MAGHRIB_ADJ = intPreferencesKey("maghrib_adj")
        val KEY_ISHA_ADJ = intPreferencesKey("isha_adj")
        val KEY_HIJRI_ADJ = intPreferencesKey("hijri_adj")

        val KEY_TASBIH_COUNT = intPreferencesKey("tasbih_count")
        val KEY_TASBIH_TOTAL = longPreferencesKey("tasbih_total")
        val KEY_TASBIH_TARGET = intPreferencesKey("tasbih_target")
        val KEY_TASBIH_DHIKR_INDEX = intPreferencesKey("tasbih_dhikr_idx")
        val KEY_TASBIH_VIBRATE = booleanPreferencesKey("tasbih_vibrate")
    }

    val userPreferencesFlow: Flow<UserPreferences> = context.dataStore.data.map { preferences ->
        val langCode = preferences[PreferencesKeys.KEY_LANGUAGE] ?: "bn"
        val lang = AppLanguage.entries.find { it.code == langCode } ?: AppLanguage.BENGALI

        val calcMethodId = preferences[PreferencesKeys.KEY_CALC_METHOD] ?: "bangladesh"
        val calcMethod = CalculationMethod.entries.find { it.id == calcMethodId } ?: CalculationMethod.BANGLADESH

        val juristicId = preferences[PreferencesKeys.KEY_JURISTIC_METHOD] ?: "hanafi"
        val juristicMethod = JuristicMethod.entries.find { it.id == juristicId } ?: JuristicMethod.HANAFI

        val cityName = preferences[PreferencesKeys.KEY_CITY_NAME] ?: PredefinedLocations.DEFAULT_LOCATION.cityName
        val countryName = preferences[PreferencesKeys.KEY_COUNTRY_NAME] ?: PredefinedLocations.DEFAULT_LOCATION.countryName
        val latitude = preferences[PreferencesKeys.KEY_LATITUDE] ?: PredefinedLocations.DEFAULT_LOCATION.latitude
        val longitude = preferences[PreferencesKeys.KEY_LONGITUDE] ?: PredefinedLocations.DEFAULT_LOCATION.longitude
        val timezone = preferences[PreferencesKeys.KEY_TIMEZONE] ?: PredefinedLocations.DEFAULT_LOCATION.timezoneId
        val autoGps = preferences[PreferencesKeys.KEY_AUTO_GPS] ?: true

        val adhanAudioId = preferences[PreferencesKeys.KEY_ADHAN_AUDIO] ?: "makkah"
        val adhanAudio = AdhanAudioOption.fromId(adhanAudioId)

        UserPreferences(
            language = lang,
            calculationMethod = calcMethod,
            juristicMethod = juristicMethod,
            location = LocationData(cityName, countryName, latitude, longitude, timezone, autoGps),
            isAutoGps = autoGps,
            adhanAudio = adhanAudio,
            fajrEnabled = preferences[PreferencesKeys.KEY_FAJR_ENABLED] ?: true,
            dhuhrEnabled = preferences[PreferencesKeys.KEY_DHUHR_ENABLED] ?: true,
            asrEnabled = preferences[PreferencesKeys.KEY_ASR_ENABLED] ?: true,
            maghribEnabled = preferences[PreferencesKeys.KEY_MAGHRIB_ENABLED] ?: true,
            ishaEnabled = preferences[PreferencesKeys.KEY_ISHA_ENABLED] ?: true,
            fajrSilent = preferences[PreferencesKeys.KEY_FAJR_SILENT] ?: false,
            dhuhrSilent = preferences[PreferencesKeys.KEY_DHUHR_SILENT] ?: false,
            asrSilent = preferences[PreferencesKeys.KEY_ASR_SILENT] ?: false,
            maghribSilent = preferences[PreferencesKeys.KEY_MAGHRIB_SILENT] ?: false,
            ishaSilent = preferences[PreferencesKeys.KEY_ISHA_SILENT] ?: false,
            vibrateEnabled = preferences[PreferencesKeys.KEY_VIBRATE] ?: true,
            fajrAdjustment = preferences[PreferencesKeys.KEY_FAJR_ADJ] ?: 0,
            dhuhrAdjustment = preferences[PreferencesKeys.KEY_DHUHR_ADJ] ?: 0,
            asrAdjustment = preferences[PreferencesKeys.KEY_ASR_ADJ] ?: 0,
            maghribAdjustment = preferences[PreferencesKeys.KEY_MAGHRIB_ADJ] ?: 0,
            ishaAdjustment = preferences[PreferencesKeys.KEY_ISHA_ADJ] ?: 0,
            hijriAdjustment = preferences[PreferencesKeys.KEY_HIJRI_ADJ] ?: 0,
            tasbihCount = preferences[PreferencesKeys.KEY_TASBIH_COUNT] ?: 0,
            tasbihTotal = preferences[PreferencesKeys.KEY_TASBIH_TOTAL] ?: 0L,
            tasbihTarget = preferences[PreferencesKeys.KEY_TASBIH_TARGET] ?: 33,
            tasbihDhikrIndex = preferences[PreferencesKeys.KEY_TASBIH_DHIKR_INDEX] ?: 0,
            tasbihVibrate = preferences[PreferencesKeys.KEY_TASBIH_VIBRATE] ?: true
        )
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.dataStore.edit { it[PreferencesKeys.KEY_LANGUAGE] = language.code }
    }

    suspend fun setCalculationMethod(method: CalculationMethod) {
        context.dataStore.edit { it[PreferencesKeys.KEY_CALC_METHOD] = method.id }
    }

    suspend fun setJuristicMethod(method: JuristicMethod) {
        context.dataStore.edit { it[PreferencesKeys.KEY_JURISTIC_METHOD] = method.id }
    }

    suspend fun setLocation(location: LocationData, isAutoGps: Boolean) {
        context.dataStore.edit {
            it[PreferencesKeys.KEY_CITY_NAME] = location.cityName
            it[PreferencesKeys.KEY_COUNTRY_NAME] = location.countryName
            it[PreferencesKeys.KEY_LATITUDE] = location.latitude
            it[PreferencesKeys.KEY_LONGITUDE] = location.longitude
            it[PreferencesKeys.KEY_TIMEZONE] = location.timezoneId
            it[PreferencesKeys.KEY_AUTO_GPS] = isAutoGps
        }
    }

    suspend fun setAdhanAudio(audio: AdhanAudioOption) {
        context.dataStore.edit { it[PreferencesKeys.KEY_ADHAN_AUDIO] = audio.id }
    }

    suspend fun setPrayerAdhanEnabled(prayerId: String, enabled: Boolean) {
        context.dataStore.edit {
            when (prayerId) {
                "fajr" -> it[PreferencesKeys.KEY_FAJR_ENABLED] = enabled
                "dhuhr" -> it[PreferencesKeys.KEY_DHUHR_ENABLED] = enabled
                "asr" -> it[PreferencesKeys.KEY_ASR_ENABLED] = enabled
                "maghrib" -> it[PreferencesKeys.KEY_MAGHRIB_ENABLED] = enabled
                "isha" -> it[PreferencesKeys.KEY_ISHA_ENABLED] = enabled
            }
        }
    }

    suspend fun setPrayerSilent(prayerId: String, silent: Boolean) {
        context.dataStore.edit {
            when (prayerId) {
                "fajr" -> it[PreferencesKeys.KEY_FAJR_SILENT] = silent
                "dhuhr" -> it[PreferencesKeys.KEY_DHUHR_SILENT] = silent
                "asr" -> it[PreferencesKeys.KEY_ASR_SILENT] = silent
                "maghrib" -> it[PreferencesKeys.KEY_MAGHRIB_SILENT] = silent
                "isha" -> it[PreferencesKeys.KEY_ISHA_SILENT] = silent
            }
        }
    }

    suspend fun setAdjustment(prayerId: String, minutes: Int) {
        context.dataStore.edit {
            when (prayerId) {
                "fajr" -> it[PreferencesKeys.KEY_FAJR_ADJ] = minutes
                "dhuhr" -> it[PreferencesKeys.KEY_DHUHR_ADJ] = minutes
                "asr" -> it[PreferencesKeys.KEY_ASR_ADJ] = minutes
                "maghrib" -> it[PreferencesKeys.KEY_MAGHRIB_ADJ] = minutes
                "isha" -> it[PreferencesKeys.KEY_ISHA_ADJ] = minutes
            }
        }
    }

    suspend fun setHijriAdjustment(days: Int) {
        context.dataStore.edit { it[PreferencesKeys.KEY_HIJRI_ADJ] = days }
    }

    suspend fun updateTasbih(count: Int, total: Long) {
        context.dataStore.edit {
            it[PreferencesKeys.KEY_TASBIH_COUNT] = count
            it[PreferencesKeys.KEY_TASBIH_TOTAL] = total
        }
    }

    suspend fun setTasbihTarget(target: Int) {
        context.dataStore.edit { it[PreferencesKeys.KEY_TASBIH_TARGET] = target }
    }

    suspend fun setTasbihDhikrIndex(index: Int) {
        context.dataStore.edit { it[PreferencesKeys.KEY_TASBIH_DHIKR_INDEX] = index }
    }

    suspend fun setTasbihVibrate(enabled: Boolean) {
        context.dataStore.edit { it[PreferencesKeys.KEY_TASBIH_VIBRATE] = enabled }
    }
}
