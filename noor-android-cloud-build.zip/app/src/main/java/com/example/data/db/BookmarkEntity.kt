package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bookmarks")
data class BookmarkEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val type: String, // "quran_surah", "quran_ayah", "dua"
    val referenceId: String,
    val title: String,
    val subtitle: String,
    val arabicText: String? = null,
    val translation: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
