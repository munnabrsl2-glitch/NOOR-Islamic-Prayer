package com.example.data.model

enum class AppLanguage(val code: String, val displayName: String, val nativeName: String) {
    BENGALI("bn", "Bengali", "বাংলা"),
    ENGLISH("en", "English", "English"),
    ARABIC("ar", "Arabic", "العربية")
}

enum class PrayerType(
    val id: String,
    val nameEn: String,
    val nameBn: String,
    val nameAr: String,
    val isFard: Boolean = true
) {
    FAJR("fajr", "Fajr", "ফজর", "الفجر", true),
    SUNRISE("sunrise", "Sunrise", "সূর্যোদয়", "الشروق", false),
    DHUHR("dhuhr", "Dhuhr", "যোহর", "الظهر", true),
    ASR("asr", "Asr", "আসর", "العصر", true),
    MAGHRIB("maghrib", "Maghrib", "মাগরিব", "المغرب", true),
    ISHA("isha", "Isha", "এশা", "العشاء", true);

    fun getLocalizedName(lang: AppLanguage): String {
        return when (lang) {
            AppLanguage.BENGALI -> nameBn
            AppLanguage.ARABIC -> nameAr
            AppLanguage.ENGLISH -> nameEn
        }
    }
}

enum class CalculationMethod(
    val id: String,
    val titleEn: String,
    val titleBn: String,
    val fajrAngle: Double,
    val ishaAngle: Double,
    val ishaMinutesAfterMaghrib: Double? = null
) {
    BANGLADESH(
        "bangladesh",
        "Islamic Foundation Bangladesh",
        "ইসলামিক ফাউন্ডেশন বাংলাদেশ",
        18.0,
        18.0
    ),
    KARACHI(
        "karachi",
        "Univ. of Islamic Sciences, Karachi",
        "ইসলামিক সাইন্সেস করাচি",
        18.0,
        18.0
    ),
    MWL(
        "mwl",
        "Muslim World League (MWL)",
        "মুসলিম ওয়ার্ল্ড লীগ",
        18.0,
        17.0
    ),
    MAKKAH(
        "makkah",
        "Umm Al-Qura University, Makkah",
        "উম্মুল কুরা, মক্কা",
        18.5,
        0.0,
        ishaMinutesAfterMaghrib = 90.0
    ),
    ISNA(
        "isna",
        "Islamic Society of North America",
        "ইসলামিক সোসাইটি অফ নর্থ আমেরিকা",
        15.0,
        15.0
    ),
    EGYPT(
        "egypt",
        "Egyptian General Authority of Survey",
        "মিশরীয় সাধারণ জরিপ কর্তৃপক্ষ",
        19.5,
        17.5
    );

    fun getTitle(lang: AppLanguage): String = if (lang == AppLanguage.BENGALI) titleBn else titleEn
}

enum class JuristicMethod(
    val id: String,
    val titleEn: String,
    val titleBn: String,
    val shadowFactor: Double
) {
    HANAFI("hanafi", "Hanafi (Standard in South Asia)", "হানাফী (দক্ষিণ এশিয়ায় প্রচলিত)", 2.0),
    SHAFI("shafi", "Shafi, Maliki, Hanbali", "শাফেয়ী, মালেকী, হাম্বলী", 1.0);

    fun getTitle(lang: AppLanguage): String = if (lang == AppLanguage.BENGALI) titleBn else titleEn
}

data class PrayerTimeItem(
    val type: PrayerType,
    val timeMillis: Long,
    val timeFormatted: String,
    val isNext: Boolean = false,
    val isPassed: Boolean = false,
    val isAdhanEnabled: Boolean = true,
    val isSilent: Boolean = false
)

data class PrayerSchedule(
    val dateEpochDays: Long,
    val fajr: Long,
    val sunrise: Long,
    val dhuhr: Long,
    val asr: Long,
    val maghrib: Long,
    val isha: Long,
    val sehriEnd: Long, // Typically Fajr
    val iftarTime: Long, // Typically Maghrib
    val midnight: Long,
    val tahajjudLastThird: Long
)

data class LocationData(
    val cityName: String,
    val countryName: String,
    val latitude: Double,
    val longitude: Double,
    val timezoneId: String,
    val isGps: Boolean = false
)

enum class AdhanAudioOption(val id: String, val title: String, val rawResName: String) {
    MAKKAH("makkah", "Adhan Makkah (মক্কা মুকাররমা)", "adhan_makkah"),
    MADINAH("madinah", "Adhan Madinah (মদিনা মুনাওয়ারা)", "adhan_madinah"),
    SHORT("short", "Short Takbeer Alert (সংক্ষিপ্ত তাকবীর)", "adhan_short");

    companion object {
        fun fromId(id: String): AdhanAudioOption = entries.find { it.id == id } ?: MAKKAH
    }
}
