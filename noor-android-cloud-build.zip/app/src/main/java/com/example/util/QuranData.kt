package com.example.util

data class SurahInfo(
    val number: Int,
    val nameEn: String,
    val nameBn: String,
    val nameAr: String,
    val englishMeaning: String,
    val bengaliMeaning: String,
    val versesCount: Int,
    val isMakki: Boolean
)

data class AyahDetail(
    val surahNumber: Int,
    val ayahNumber: Int,
    val arabicText: String,
    val pronunciationBn: String,
    val translationBn: String,
    val translationEn: String
)

object QuranData {

    val SURAH_LIST: List<SurahInfo> = listOf(
        SurahInfo(1, "Al-Fatihah", "আল-ফাতিহা", "الفاتحة", "The Opening", "সূচনা", 7, true),
        SurahInfo(2, "Al-Baqarah", "আল-বাকারা", "البقرة", "The Cow", "বকনা-বাছুর", 286, false),
        SurahInfo(3, "Ali 'Imran", "আলে ইমরান", "آل عمران", "Family of Imran", "ইমরানের পরিবার", 200, false),
        SurahInfo(4, "An-Nisa", "আন-নিসা", "النساء", "The Women", "নারী", 176, false),
        SurahInfo(5, "Al-Ma'idah", "আল-মায়িদাহ", "المائدة", "The Table Spread", "খাদ্য পরিবেশিত টেবিল", 120, false),
        SurahInfo(6, "Al-An'am", "আল-আনআম", "الأنعام", "The Cattle", "গৃহপালিত পশু", 165, true),
        SurahInfo(7, "Al-A'raf", "আল-আরাফ", "الأعراف", "The Heights", "উঁচু স্থানসমূহ", 206, true),
        SurahInfo(8, "Al-Anfal", "আল-আনফাল", "الأنفال", "The Spoils of War", "যুদ্ধলব্ধ ধন-সম্পদ", 75, false),
        SurahInfo(9, "At-Tawbah", "আত-তাওবাহ", "التوبة", "The Repentance", "অনুশোচনা", 129, false),
        SurahInfo(10, "Yunus", "ইউনুস", "يونس", "Jonah", "ইউনুস (আ.)", 109, true),
        SurahInfo(11, "Hud", "হুদ", "هود", "Hud", "হুদ (আ.)", 123, true),
        SurahInfo(12, "Yusuf", "ইউসুফ", "يوسف", "Joseph", "ইউসুফ (আ.)", 111, true),
        SurahInfo(13, "Ar-Ra'd", "আর-রাদ", "الرعد", "The Thunder", "বজ্রপাত", 43, false),
        SurahInfo(14, "Ibrahim", "ইব্রাহিম", "إبراهيم", "Abraham", "ইব্রাহিম (আ.)", 52, true),
        SurahInfo(15, "Al-Hijr", "আল-হিজর", "الحجر", "The Rocky Tract", "পাথুরে পাহাড়", 99, true),
        SurahInfo(16, "An-Nahl", "আন-নাহল", "النحل", "The Bee", "মৌমাছি", 128, true),
        SurahInfo(17, "Al-Isra", "আল-ইসরা", "الإسراء", "The Night Journey", "নিশারাভিসার", 111, true),
        SurahInfo(18, "Al-Kahf", "আল-কাহফ", "الكهف", "The Cave", "গুহা", 110, true),
        SurahInfo(19, "Maryam", "মারইয়াম", "مريم", "Mary", "মারইয়াম (আ.)", 98, true),
        SurahInfo(20, "Taha", "ত্বোয়া-হা", "طه", "Ta-Ha", "ত্বোয়া-হা", 135, true),
        SurahInfo(21, "Al-Anbiya", "আল-আম্বিয়া", "الأنبياء", "The Prophets", "নবীগণ", 112, true),
        SurahInfo(22, "Al-Hajj", "আল-হাজ্জ", "الحج", "The Pilgrimage", "হজ", 78, false),
        SurahInfo(23, "Al-Mu'minun", "আল-মু'মিনুন", "المؤمنون", "The Believers", "মুমিনগণ", 118, true),
        SurahInfo(24, "An-Nur", "আন-নূর", "النور", "The Light", "জ্যোতি", 64, false),
        SurahInfo(25, "Al-Furqan", "আল-ফুরকান", "الفرقان", "The Criterion", "সত্য-মিথ্যার মানদণ্ড", 77, true),
        SurahInfo(26, "Ash-Shu'ara", "আশ-শুআরা", "الشعراء", "The Poets", "কবিগণ", 227, true),
        SurahInfo(27, "An-Naml", "আন-নামল", "النمل", "The Ant", "পিপীলিকা", 93, true),
        SurahInfo(28, "Al-Qasas", "আল-কাসাস", "القصص", "The Stories", "কাহিনীসমূহ", 88, true),
        SurahInfo(29, "Al-Ankabut", "আল-আনকাবুত", "العنكبوت", "The Spider", "মাকড়সা", 69, true),
        SurahInfo(30, "Ar-Rum", "আর-রূম", "الروم", "The Romans", "রোমবাসী", 60, true),
        SurahInfo(31, "Luqman", "লুকমান", "لقمان", "Luqman", "লুকমান", 34, true),
        SurahInfo(32, "As-Sajdah", "আস-সাজদাহ", "السجدة", "The Prostration", "সিজদা", 30, true),
        SurahInfo(33, "Al-Ahzab", "আল-আহযাব", "الأحزاب", "The Combined Forces", "জোটবদ্ধ বাহিনী", 73, false),
        SurahInfo(34, "Saba", "সাবা", "سبإ", "Sheba", "সাবা জাতি", 54, true),
        SurahInfo(35, "Fatir", "ফাতির", "فاطر", "The Originator", "স্রষ্টা", 45, true),
        SurahInfo(36, "Ya-Sin", "ইয়াসীন", "يس", "Ya-Sin", "ইয়াসীন (কুরআনের হৃৎপিণ্ড)", 83, true),
        SurahInfo(37, "As-Saffat", "আস-সাফফাত", "الصافات", "Those Range in Ranks", "সারিবদ্ধ দলসমূহ", 182, true),
        SurahInfo(38, "Sad", "সোয়াদ", "ص", "Sad", "সোয়াদ", 88, true),
        SurahInfo(39, "Az-Zumar", "আজ-জুমার", "الزمر", "The Troops", "দলবদ্ধ জনতা", 75, true),
        SurahInfo(40, "Ghafir", "গাফির", "غافر", "The Forgiver", "ক্ষমাকারী", 85, true),
        SurahInfo(41, "Fussilat", "ফুসসিলাত", "فصلت", "Explained in Detail", "সুস্পষ্ট বিবরণ", 54, true),
        SurahInfo(42, "Ash-Shura", "আশ-শূরা", "الشورى", "The Consultation", "পরামর্শ", 53, true),
        SurahInfo(43, "Az-Zukhruf", "আজ-জুখরুফ", "الزخرف", "The Gold Adornment", "স্বর্ণালঙ্কার", 89, true),
        SurahInfo(44, "Ad-Dukhan", "আদ-দুখান", "الدخان", "The Smoke", "ধোঁয়া", 59, true),
        SurahInfo(45, "Al-Jathiyah", "আল-জাসিয়াহ", "الجاثية", "The Crouching", "নতজানু", 37, true),
        SurahInfo(46, "Al-Ahqaf", "আল-আহকাফ", "الأحقاف", "The Curved Sand-hills", "বালুকাময় টিলা", 35, true),
        SurahInfo(47, "Muhammad", "মুহাম্মদ", "محمد", "Muhammad", "মুহাম্মদ (সা.)", 38, false),
        SurahInfo(48, "Al-Fath", "আল-ফাতহ", "الفتح", "The Victory", "বিজয়", 29, false),
        SurahInfo(49, "Al-Hujurat", "আল-হুজুরাত", "الحجرات", "The Dwellings", "কক্ষসমূহ", 18, false),
        SurahInfo(50, "Qaf", "কাফ", "ق", "Qaf", "কাফ", 45, true),
        SurahInfo(55, "Ar-Rahman", "আর-রাহমান", "الرحمن", "The Beneficent", "পরম করুণাময়", 78, false),
        SurahInfo(56, "Al-Waqi'ah", "আল-ওয়াকিয়াহ", "الواقعة", "The Inevitable", "সুনিশ্চিত ঘটনা", 96, true),
        SurahInfo(67, "Al-Mulk", "আল-মুলক", "الملك", "The Sovereignty", "সার্বভৌম কর্তৃত্ব", 30, true),
        SurahInfo(93, "Ad-Duha", "আদ-দুহা", "الضحى", "The Morning Hours", "পূর্বাহ্ণ", 11, true),
        SurahInfo(94, "Ash-Sharh", "আল-ইনশিরাহ", "الشرح", "The Relief", "বক্ষ উন্মোচন", 8, true),
        SurahInfo(97, "Al-Qadr", "আল-কদর", "القدر", "The Power", "মর্যাদা ও মহিমান্বিত রাত", 5, true),
        SurahInfo(103, "Al-Asr", "আল-আসর", "العصر", "The Declining Day", "সময় ও কাল", 3, true),
        SurahInfo(108, "Al-Kawthar", "আল-কাউসার", "الكوثر", "The Abundance", "প্রচুর কল্যাণ", 3, true),
        SurahInfo(109, "Al-Kafirun", "আল-কাফিরুন", "الكافرون", "The Disbelievers", "কাফেরগণ", 6, true),
        SurahInfo(110, "An-Nasr", "আন-নাসর", "النصر", "The Divine Support", "সাহায্য ও বিজয়", 3, false),
        SurahInfo(112, "Al-Ikhlas", "আল-ইখলাস", "الإخلاص", "The Sincerity", "একনিষ্ঠতা ও তাওহীদ", 4, true),
        SurahInfo(113, "Al-Falaq", "আল-ফালাক", "الفلق", "The Daybreak", "নিশিভোর", 5, true),
        SurahInfo(114, "An-Nas", "আন-নাস", "الناس", "Mankind", "মানবজাতি", 6, true)
    )

    val SAMPLE_AYAHS: Map<Int, List<AyahDetail>> = mapOf(
        1 to listOf(
            AyahDetail(1, 1, "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ", "বিসমিল্লাহির রাহমানির রাহিম", "পরম করুণাময় অসীম দয়ালু আল্লাহর নামে শুরু করছি।", "In the name of Allah, the Entirely Merciful, the Especially Merciful."),
            AyahDetail(1, 2, "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ", "আলহামদু লিল্লাহি রাব্বিল আলামীন", "সমস্ত প্রশংসা আল্লাহ তাআলার জন্য, যিনি সকল সৃষ্টির পালনকর্তা।", "[All] praise is [due] to Allah, Lord of the worlds -"),
            AyahDetail(1, 3, "الرَّحْمَٰنِ الرَّحِيمِ", "আর-রাহমানির রাহিম", "যিনি পরম করুণাময় ও অসীম দয়ালু।", "The Entirely Merciful, the Especially Merciful,"),
            AyahDetail(1, 4, "مَالِكِ يَوْمِ الدِّينِ", "মালিকি ইয়াওমিদ্দীন", "যিনি বিচার দিবসের একমাত্র মালিক।", "Sovereign of the Day of Recompense."),
            AyahDetail(1, 5, "إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ", "ইয়্যাক্বা না'বুদু ওয়া ইয়্যাক্বা নাস্তায়ী'ন", "আমরা কেবল আপনারই ইবাদত করি এবং কেবল আপনারই সাহায্য প্রার্থনা করি।", "It is You we worship and You we ask for help."),
            AyahDetail(1, 6, "اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ", "ইহদিনাস সিরাতাল মুস্তাক্বীম", "আমাদেরকে সরল সঠিক পথ প্রদর্শন করুন।", "Guide us to the straight path -"),
            AyahDetail(1, 7, "صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ", "সিরাতাল্লাযীনা আন'আমতা আলাইহিম, গাইরিল মাগদূবি আলাইহিম ওয়ালাদ্দোয়াল্লীন", "সে সমস্ত লোকের পথ, যাদের আপনি পুরস্কৃত করেছেন; তাদের পথ নয় যাদের ওপর গজব পড়েছে এবং যারা পথভ্রষ্ট হয়েছে।", "The path of those upon whom You have bestowed favor, not of those who have evoked [Your] anger or of those who are astray.")
        ),
        112 to listOf(
            AyahDetail(112, 1, "قُلْ هُوَ اللَّهُ أَحَدٌ", "কুল হুওয়াল্লাহু আহাদ", "বলুন, তিনিই আল্লাহ, একক ও অদ্বিতীয়।", "Say, He is Allah, [who is] One,"),
            AyahDetail(112, 2, "اللَّهُ الصَّمَدُ", "আল্লাহুস সামাদ", "আল্লাহ কারো মুখাপেক্ষী নন, সবাই তাঁর মুখাপেক্ষী।", "Allah, the Eternal Refuge."),
            AyahDetail(112, 3, "لَمْ يَلِدْ وَلَمْ يُولَدْ", "লাম ইয়ালিদ ওয়া লাম ইউলাদ", "তিনি কাউকে জন্ম দেননি এবং তাঁকেও কেউ জন্ম দেয়নি।", "He neither begets nor is born,"),
            AyahDetail(112, 4, "وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ", "ওয়া লাম ইয়াকুল লাহু কুফুওয়ান আহাদ", "এবং তাঁর সমকক্ষ বা তুল্য কেউ নেই।", "Nor is there to Him any equivalent.")
        ),
        113 to listOf(
            AyahDetail(113, 1, "قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ", "কুল আউযু বিরাব্বিল ফালাক", "বলুন, আমি আশ্রয় প্রার্থনা করছি প্রভাতের পালনকর্তার কাছে,", "Say, I seek refuge in the Lord of daybreak"),
            AyahDetail(113, 2, "مِن شَرِّ مَا خَلَقَ", "মিন শাররি মা খালাক", "তিনি যা সৃষ্টি করেছেন তার অনিষ্ট থেকে,", "From the evil of that which He created"),
            AyahDetail(113, 3, "وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ", "ওয়া মিন শাররি গাসিকিন ইযা ওয়াকাব", "অন্ধকার রাত্রির অনিষ্ট থেকে যখন তা সমাগত হয়,", "And from the evil of darkness when it settles"),
            AyahDetail(113, 4, "وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ", "ওয়া মিন শাররিন নাফ্ফাসাতি ফিল উকাদ", "এবং গ্রন্থিতে ফুৎকার দিয়ে জাদুকারিনীদের অনিষ্ট থেকে,", "And from the evil of the blowers in knots"),
            AyahDetail(113, 5, "وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ", "ওয়া মিন শাররি হাসিদিন ইযা হাসাদ", "এবং হিংসুকের অনিষ্ট থেকে যখন সে হিংসা করে।", "And from the evil of an envier when he envies.")
        ),
        114 to listOf(
            AyahDetail(114, 1, "قُلْ أَعُوذُ بِرَبِّ النَّاسِ", "কুল আউযু বিরাব্বিন নাস", "বলুন, আমি আশ্রয় চাই মানবজাতির পালনকর্তার কাছে,", "Say, I seek refuge in the Lord of mankind,"),
            AyahDetail(114, 2, "مَلِكِ النَّاسِ", "মালিকিন নাস", "মানবজাতির অধিপতির কাছে,", "The Sovereign of mankind,"),
            AyahDetail(114, 3, "إِلَٰهِ النَّاسِ", "ইলাহিন নাস", "মানবজাতির একমাত্র মা'বূদের কাছে,", "The God of mankind,"),
            AyahDetail(114, 4, "مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ", "মিন শাররিল ওয়াসওয়াসিল খান্নাস", "সেই গোপন কুমন্ত্রণাদাতার অনিষ্ট থেকে,", "From the evil of the retreating whisperer -"),
            AyahDetail(114, 5, "الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ", "আল্লাযী ইউওয়াসউইসু ফী সুদূরিন নাস", "যে মানুষের অন্তরে কুমন্ত্রণা দেয়,", "Who whispers [evil] into the breasts of mankind -"),
            AyahDetail(114, 6, "مِنَ الْجِنَّةِ وَالنَّاسِ", "মিনাল জিন্নাতি ওয়ান নাস", "জিন এবং মানুষদের মধ্য থেকে।", "From among the jinn and mankind.")
        ),
        108 to listOf(
            AyahDetail(108, 1, "إِنَّا أَعْطَيْنَاكَ الْكَوْثَرَ", "ইন্না আ'তাইনা কাল কাউসার", "নিশ্চয়ই আমি আপনাকে কাউসার (প্রচুর কল্যাণ) দান করেছি।", "Indeed, We have granted you, [O Muhammad], al-Kawthar."),
            AyahDetail(108, 2, "فَصَلِّ لِرَبِّكَ وَانْحَرْ", "ফাসাল্লি লিরাব্বিকা ওয়ানহার", "অতএব আপনার প্রতিপালকের উদ্দেশে সালাত আদায় করুন এবং কুরবানি করুন।", "So pray to your Lord and sacrifice [to Him alone]."),
            AyahDetail(108, 3, "إِنَّ شَانِئَكَ هُوَ الْأَبْتَرُ", "ইন্না শানি'আকা হুওয়াল আবতার", "নিশ্চয়ই আপনার শত্রুই তো নির্বংশ, লেজকাটা।", "Indeed, your enemy is the one cut off.")
        ),
        103 to listOf(
            AyahDetail(103, 1, "وَالْعَصْرِ", "ওয়াল আসর", "সময়ের শপথ,", "By time,"),
            AyahDetail(103, 2, "إِنَّ الْإِنسَانَ لَفِي خُسْرٍ", "ইন্নাল ইনসানা লাফী খুসর", "নিশ্চয়ই সমগ্র মানুষ ক্ষতিগ্রস্ত অবস্থায় রয়েছে,", "Indeed, mankind is in loss,"),
            AyahDetail(103, 3, "إِلَّا الَّذِينَ آمَنُوا وَعَمِلُوا الصَّالِحَاتِ وَتَوَاصَوْا بِالْحَقِّ وَتَوَاصَوْا بِالصَّبْرِ", "ইল্লাল্লাযীনা আমানু ওয়া আমিলুস সালিহাতি ওয়া তাওয়াসাও বিল হাক্কি ওয়া তাওয়াসাও বিস সাবর", "তারা ব্যতীত যারা ঈমান এনেছে, সৎকাজ করেছে এবং পরস্পরকে সত্যের উপদেশ দিয়েছে ও ধৈর্যের উপদেশ দিয়েছে।", "Except for those who have believed and done righteous deeds and advised each other to truth and advised each other to patience.")
        ),
        67 to listOf(
            AyahDetail(67, 1, "تَبَارَكَ الَّذِي بِيَدِهِ الْمُلْكُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ", "তাবারাকাল্লাযী বিয়াদিহিল মুলকু ওয়াহুওয়া আলা কুল্লি শাইয়িন কাদীর", "মহিমান্বিত তিনি, যাঁর হাতে সমস্ত রাজত্ব এবং তিনি সর্ববিষয়ে সর্বশক্তিমান।", "Blessed is He in whose hand is dominion, and He is over all things competent -"),
            AyahDetail(67, 2, "الَّذِي خَلَقَ الْمَوْتَ وَالْحَيَاةَ لِيَبْلُوَكُمْ أَيُّكُمْ أَحْسَنُ عَمَلًا", "আল্লাযী খালাকাল মাওতা ওয়াল হায়াতা লিয়াবলুয়াকুম আইয়্যুকুম আহসানু আমালা", "যিনি সৃষ্টি করেছেন মৃত্যু ও জীবন, যাতে তোমাদের পরীক্ষা করেন কে কর্মে সর্বোত্তম।", "[He] who created death and life to test you [as to] which of you is best in deed -"),
            AyahDetail(67, 3, "الَّذِي خَلَقَ سَبْعَ سَمَاوَاتٍ طِبَاقًا", "আল্লাযী খালাকা সাব'আ সামাওয়াতিম তিবাঁকা", "যিনি সপ্ত আকাশ স্তরে স্তরে সৃষ্টি করেছেন।", "[And] who created seven heavens in layers.")
        ),
        36 to listOf(
            AyahDetail(36, 1, "يس", "ইয়াসীন", "ইয়াসীন।", "Ya, Seen."),
            AyahDetail(36, 2, "وَالْقُرْآنِ الْحَكِيمِ", "ওয়াল কুরআনিল হাকীম", "প্রজ্ঞাময় কুরআনের শপথ,", "By the wise Qur'an."),
            AyahDetail(36, 3, "إِنَّكَ لَمِنَ الْمُرْسَلِينَ", "ইন্নাকা লামিনাল মুরসালীন", "নিশ্চয়ই আপনি প্রেরিত রাসুলদের একজন,", "Indeed you, [O Muhammad], are from among the messengers,"),
            AyahDetail(36, 4, "عَلَىٰ صِرَاطٍ مُّسْتَقِيمٍ", "আলা সিরাতিম মুস্তাক্বীম", "সরল সঠিক পথের ওপর প্রতিষ্ঠিত।", "On a straight path."),
            AyahDetail(36, 5, "تَنزِيلَ الْعَزِيزِ الرَّحِيمِ", "তানযীলাল আযীযির রাহীম", "কুরআন পরাক্রমশালী পরম দয়ালু আল্লাহর অবতীর্ণ।", "[This is] a revelation of the Exalted in Might, the Merciful.")
        )
    )

    fun getAyahsForSurah(surahNumber: Int): List<AyahDetail> {
        return SAMPLE_AYAHS[surahNumber] ?: listOf(
            AyahDetail(
                surahNumber = surahNumber,
                ayahNumber = 1,
                arabicText = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
                pronunciationBn = "বিসমিল্লাহির রাহমানির রাহিম",
                translationBn = "পরম করুণাময় অসীম দয়ালু আল্লাহর নামে শুরু করছি।",
                translationEn = "In the name of Allah, the Entirely Merciful, the Especially Merciful."
            ),
            AyahDetail(
                surahNumber = surahNumber,
                ayahNumber = 2,
                arabicText = "الْحَمْدُ لِلَّهِ الَّذِي أَنزَلَ عَلَىٰ عَبْدِهِ الْكِتَابَ",
                pronunciationBn = "আলহামদু লিল্লাহিল্লাযী আনযালা আলা আবদিহিল কিতাব",
                translationBn = "সমস্ত প্রশংসা আল্লাহর, যিনি তাঁর বান্দার ওপর এই কিতাব অবতীর্ণ করেছেন।",
                translationEn = "[All] praise is due to Allah, who has sent down upon His Servant the Book."
            )
        )
    }
}
