package com.example.util

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class CompassState(
    val deviceAzimuthDegrees: Float = 0f,
    val qiblaAngleDegrees: Float = 0f,
    val needleAngleDegrees: Float = 0f, // Direction needle should rotate
    val distanceToMakkahKm: Double = 0.0,
    val accuracy: Int = SensorManager.SENSOR_STATUS_ACCURACY_HIGH,
    val isSensorAvailable: Boolean = true
)

class SensorCompass(context: Context) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val rotationVectorSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
    private val accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)

    private val _compassState = MutableStateFlow(CompassState())
    val compassState: StateFlow<CompassState> = _compassState.asStateFlow()

    private var userLatitude: Double = 23.8103
    private var userLongitude: Double = 90.4125
    private var calculatedQiblaBearing: Float = 0f
    private var calculatedDistanceKm: Double = 0.0

    private val rotationMatrix = FloatArray(9)
    private val orientationAngles = FloatArray(3)
    private val lastAccelerometer = FloatArray(3)
    private val lastMagnetometer = FloatArray(3)
    private var lastAccelerometerSet = false
    private var lastMagnetometerSet = false

    private var smoothedAzimuth: Float = 0f

    companion object {
        const val KAABA_LATITUDE = 21.422487
        const val KAABA_LONGITUDE = 39.826206
    }

    init {
        updateQiblaBearing(userLatitude, userLongitude)
    }

    fun updateLocation(lat: Double, lng: Double) {
        userLatitude = lat
        userLongitude = lng
        updateQiblaBearing(lat, lng)
    }

    private fun updateQiblaBearing(lat: Double, lng: Double) {
        val phi1 = Math.toRadians(lat)
        val phi2 = Math.toRadians(KAABA_LATITUDE)
        val deltaLambda = Math.toRadians(KAABA_LONGITUDE - lng)

        val y = sin(deltaLambda) * cos(phi2)
        val x = cos(phi1) * sin(phi2) - sin(phi1) * cos(phi2) * cos(deltaLambda)
        var qibla = Math.toDegrees(atan2(y, x))
        qibla = (qibla + 360) % 360
        calculatedQiblaBearing = qibla.toFloat()

        // Haversine distance
        val dLat = phi2 - phi1
        val a = sin(dLat / 2) * sin(dLat / 2) +
                cos(phi1) * cos(phi2) * sin(deltaLambda / 2) * sin(deltaLambda / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        calculatedDistanceKm = 6371.0 * c

        updateState(smoothedAzimuth, SensorManager.SENSOR_STATUS_ACCURACY_HIGH)
    }

    fun startListening() {
        val hasRotation = rotationVectorSensor != null
        val hasAccelMag = accelerometer != null && magnetometer != null

        if (!hasRotation && !hasAccelMag) {
            _compassState.value = _compassState.value.copy(
                isSensorAvailable = false,
                qiblaAngleDegrees = calculatedQiblaBearing,
                needleAngleDegrees = calculatedQiblaBearing,
                distanceToMakkahKm = calculatedDistanceKm
            )
            return
        }

        if (hasRotation) {
            sensorManager.registerListener(this, rotationVectorSensor, SensorManager.SENSOR_DELAY_UI)
        } else {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI)
            sensorManager.registerListener(this, magnetometer, SensorManager.SENSOR_DELAY_UI)
        }
    }

    fun stopListening() {
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null) return

        var azimuthDeg = 0f

        if (event.sensor.type == Sensor.TYPE_ROTATION_VECTOR) {
            SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
            SensorManager.getOrientation(rotationMatrix, orientationAngles)
            azimuthDeg = Math.toDegrees(orientationAngles[0].toDouble()).toFloat()
            azimuthDeg = (azimuthDeg + 360) % 360
        } else {
            if (event.sensor.type == Sensor.TYPE_ACCELEROMETER) {
                System.arraycopy(event.values, 0, lastAccelerometer, 0, event.values.size)
                lastAccelerometerSet = true
            } else if (event.sensor.type == Sensor.TYPE_MAGNETIC_FIELD) {
                System.arraycopy(event.values, 0, lastMagnetometer, 0, event.values.size)
                lastMagnetometerSet = true
            }

            if (lastAccelerometerSet && lastMagnetometerSet) {
                val success = SensorManager.getRotationMatrix(rotationMatrix, null, lastAccelerometer, lastMagnetometer)
                if (success) {
                    SensorManager.getOrientation(rotationMatrix, orientationAngles)
                    azimuthDeg = Math.toDegrees(orientationAngles[0].toDouble()).toFloat()
                    azimuthDeg = (azimuthDeg + 360) % 360
                }
            }
        }

        // Low pass filter
        val alpha = 0.15f
        // Angular difference handling
        var diff = azimuthDeg - smoothedAzimuth
        while (diff < -180f) diff += 360f
        while (diff > 180f) diff -= 360f
        smoothedAzimuth = (smoothedAzimuth + alpha * diff + 360f) % 360f

        updateState(smoothedAzimuth, event.accuracy)
    }

    private fun updateState(azimuth: Float, accuracy: Int) {
        val needleAngle = (calculatedQiblaBearing - azimuth + 360f) % 360f
        _compassState.value = CompassState(
            deviceAzimuthDegrees = azimuth,
            qiblaAngleDegrees = calculatedQiblaBearing,
            needleAngleDegrees = needleAngle,
            distanceToMakkahKm = calculatedDistanceKm,
            accuracy = accuracy,
            isSensorAvailable = true
        )
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        _compassState.value = _compassState.value.copy(accuracy = accuracy)
    }
}
