package com.example.util

import com.example.data.model.AppLanguage

object BengaliNumberUtil {

    private val BN_DIGITS = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')

    fun formatNumber(number: Number, language: AppLanguage): String {
        val str = number.toString()
        if (language != AppLanguage.BENGALI) return str
        return str.map { ch ->
            if (ch in '0'..'9') BN_DIGITS[ch - '0'] else ch
        }.joinToString("")
    }

    fun formatDuration(totalSeconds: Long, language: AppLanguage): String {
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60

        val hStr = if (hours < 10) "0$hours" else "$hours"
        val mStr = if (minutes < 10) "0$minutes" else "$minutes"
        val sStr = if (seconds < 10) "0$seconds" else "$seconds"

        val raw = "$hStr:$mStr:$sStr"
        return formatNumber(raw, language)
    }

    fun formatNumber(text: String, language: AppLanguage): String {
        if (language != AppLanguage.BENGALI) return text
        return text.map { ch ->
            if (ch in '0'..'9') BN_DIGITS[ch - '0'] else ch
        }.joinToString("")
    }

    fun formatPrayerTime(timeMillis: Long, language: AppLanguage, timeZoneId: String): String {
        val cal = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone(timeZoneId)).apply {
            this.timeInMillis = timeMillis
        }
        var hour = cal.get(java.util.Calendar.HOUR)
        if (hour == 0) hour = 12
        val minute = cal.get(java.util.Calendar.MINUTE)
        val amPm = if (cal.get(java.util.Calendar.AM_PM) == java.util.Calendar.AM) {
            when (language) {
                AppLanguage.BENGALI -> "ভোর"
                AppLanguage.ARABIC -> "ص"
                AppLanguage.ENGLISH -> "AM"
            }
        } else {
            when (language) {
                AppLanguage.BENGALI -> if (hour >= 6 && hour < 12) "রাত" else "দুপুর/বিকাল"
                AppLanguage.ARABIC -> "م"
                AppLanguage.ENGLISH -> "PM"
            }
        }

        val minStr = if (minute < 10) "0$minute" else "$minute"
        val rawTime = "$hour:$minStr"
        val formattedDigits = formatNumber(rawTime, language)

        return if (language == AppLanguage.BENGALI) {
            "$formattedDigits $amPm"
        } else {
            "$formattedDigits $amPm"
        }
    }
}
